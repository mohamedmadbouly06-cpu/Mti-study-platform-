import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Seeding database...");

  // Create Years
  const year2 = await prisma.year.create({
    data: {
      name: "Year 2",
      order: 2,
    },
  });

  // Create Professors
  const profAhmed = await prisma.professor.create({
    data: {
      user: {
        create: {
          email: "ahmed@mti.edu.eg",
          name: "Dr. Ahmed Hassan",
          role: "PROFESSOR",
          isPremium: true,
        },
      },
      title: "Dr.",
      department: "Cardiology",
      isVerified: true,
    },
  });

  const profSarah = await prisma.professor.create({
    data: {
      user: {
        create: {
          email: "sarah@mti.edu.eg",
          name: "Dr. Sarah Ibrahim",
          role: "PROFESSOR",
          isPremium: true,
        },
      },
      title: "Dr.",
      department: "Pharmacology",
      isVerified: true,
    },
  });

  // Create Courses
  const cardiology = await prisma.course.create({
    data: {
      name: "Cardiology",
      code: "MED201",
      description: "Study of the heart and cardiovascular system",
      color: "rose",
      yearId: year2.id,
      professorId: profAhmed.id,
    },
  });

  const pharmacology = await prisma.course.create({
    data: {
      name: "Pharmacology",
      code: "MED202",
      description: "Study of drugs and their mechanisms",
      color: "violet",
      yearId: year2.id,
      professorId: profSarah.id,
    },
  });

  const neurology = await prisma.course.create({
    data: {
      name: "Neurology",
      code: "MED203",
      description: "Study of the nervous system",
      color: "emerald",
      yearId: year2.id,
    },
  });

  // Create Modules
  const cardiacCycle = await prisma.module.create({
    data: { name: "Cardiac Cycle", order: 1, courseId: cardiology.id },
  });

  const ecg = await prisma.module.create({
    data: { name: "ECG Interpretation", order: 2, courseId: cardiology.id },
  });

  const ans = await prisma.module.create({
    data: { name: "Autonomic Nervous System", order: 1, courseId: pharmacology.id },
  });

  const cardioDrugs = await prisma.module.create({
    data: { name: "Cardiovascular Drugs", order: 2, courseId: pharmacology.id },
  });

  // Create Topics
  const topicAns = await prisma.topic.create({
    data: { name: "ANS Pharmacology", moduleId: ans.id },
  });

  const topicAspirin = await prisma.topic.create({
    data: { name: "NSAIDs", moduleId: cardioDrugs.id },
  });

  // Create Sample MCQs
  const mcqs = [
    {
      question: "Which of the following is the primary mechanism of action of Aspirin?",
      options: [
        { id: "a", text: "Reversible inhibition of COX enzymes", isCorrect: false },
        { id: "b", text: "Irreversible inhibition of COX-1 and COX-2 enzymes", isCorrect: true },
        { id: "c", text: "Selective inhibition of COX-2 only", isCorrect: false },
        { id: "d", text: "Inhibition of lipoxygenase pathway", isCorrect: false },
        { id: "e", text: "Blockade of prostaglandin receptors", isCorrect: false },
      ],
      explanation: "Aspirin works by irreversibly acetylating serine residues in the active site of both COX-1 and COX-2 enzymes. This permanently inactivates the enzymes, unlike other NSAIDs which are reversible inhibitors.",
      correctAnswerId: "b",
      difficulty: "MEDIUM" as const,
      courseId: pharmacology.id,
      topicId: topicAspirin.id,
      professorId: profSarah.id,
      source: "OFFICIAL" as const,
      verificationStatus: "VERIFIED" as const,
    },
    {
      question: "A patient on warfarin therapy requires antibiotic treatment. Which antibiotic is MOST likely to increase warfarin's anticoagulant effect?",
      options: [
        { id: "a", text: "Azithromycin", isCorrect: false },
        { id: "b", text: "Ciprofloxacin", isCorrect: true },
        { id: "c", text: "Doxycycline", isCorrect: false },
        { id: "d", text: "Nitrofurantoin", isCorrect: false },
        { id: "e", text: "Fosfomycin", isCorrect: false },
      ],
      explanation: "Ciprofloxacin inhibits CYP1A2 and can displace warfarin from protein binding sites, significantly increasing INR. Always monitor INR closely when starting antibiotics in patients on warfarin.",
      correctAnswerId: "b",
      difficulty: "HARD" as const,
      courseId: pharmacology.id,
      topicId: topicAspirin.id,
      source: "OFFICIAL" as const,
      verificationStatus: "VERIFIED" as const,
    },
    {
      question: "Which beta-blocker is most suitable for a patient with both hypertension and chronic obstructive pulmonary disease (COPD)?",
      options: [
        { id: "a", text: "Propranolol", isCorrect: false },
        { id: "b", text: "Nadolol", isCorrect: false },
        { id: "c", text: "Metoprolol", isCorrect: false },
        { id: "d", text: "Carvedilol", isCorrect: false },
        { id: "e", text: "Bisoprolol", isCorrect: true },
      ],
      explanation: "Bisoprolol is a highly selective β1-blocker with minimal β2 activity, making it safer for COPD patients. Non-selective beta-blockers like propranolol can cause bronchospasm.",
      correctAnswerId: "e",
      difficulty: "HARD" as const,
      courseId: pharmacology.id,
      topicId: topicAns.id,
      source: "OFFICIAL" as const,
      verificationStatus: "VERIFIED" as const,
    },
    {
      question: "The therapeutic index of a drug is defined as:",
      options: [
        { id: "a", text: "ED50 / LD50", isCorrect: false },
        { id: "b", text: "LD50 / ED50", isCorrect: true },
        { id: "c", text: "LD1 / ED99", isCorrect: false },
        { id: "d", text: "ED99 / LD1", isCorrect: false },
        { id: "e", text: "LD50 - ED50", isCorrect: false },
      ],
      explanation: "Therapeutic Index (TI) = LD50 / ED50. A higher TI indicates a safer drug. Digoxin has a low TI (2-3), while penicillin has a very high TI.",
      correctAnswerId: "b",
      difficulty: "EASY" as const,
      courseId: pharmacology.id,
      topicId: topicAspirin.id,
      source: "STUDENT_CONTRIBUTED" as const,
      verificationStatus: "VERIFIED" as const,
    },
    {
      question: "Which of the following is a potassium-sparing diuretic that acts as a competitive antagonist of aldosterone?",
      options: [
        { id: "a", text: "Furosemide", isCorrect: false },
        { id: "b", text: "Hydrochlorothiazide", isCorrect: false },
        { id: "c", text: "Spironolactone", isCorrect: true },
        { id: "d", text: "Acetazolamide", isCorrect: false },
        { id: "e", text: "Mannitol", isCorrect: false },
      ],
      explanation: "Spironolactone is a competitive antagonist of aldosterone at mineralocorticoid receptors. It reduces Na+ reabsorption and K+ excretion. Watch for hyperkalemia, especially with ACE inhibitors.",
      correctAnswerId: "c",
      difficulty: "MEDIUM" as const,
      courseId: pharmacology.id,
      topicId: topicAns.id,
      source: "OFFICIAL" as const,
      verificationStatus: "VERIFIED" as const,
    },
  ];

  for (const mcq of mcqs) {
    await prisma.mcqQuestion.create({ data: mcq });
  }

  // Create Flashcard Deck
  const deck = await prisma.flashcardDeck.create({
    data: {
      title: "Pharmacology Essentials",
      description: "High-yield pharmacology concepts for Year 2",
      courseId: pharmacology.id,
      creatorId: profSarah.userId,
      isOfficial: true,
      cardCount: 5,
    },
  });

  // Create Flashcards
  const flashcards = [
    {
      deckId: deck.id,
      front: "What is the mechanism of action of Aspirin?",
      back: "Irreversible inhibition of COX-1 and COX-2 enzymes, reducing prostaglandin synthesis",
      explanation: "This explains both therapeutic effects (analgesic, antipyretic, anti-inflammatory) and adverse effects (GI ulceration, bleeding risk).",
      difficulty: "MEDIUM" as const,
      order: 1,
    },
    {
      deckId: deck.id,
      front: "What is the therapeutic index (TI) formula?",
      back: "TI = LD50 / ED50",
      explanation: "A higher TI indicates a safer drug. Digoxin has a low TI (2-3), while penicillin has a very high TI.",
      difficulty: "EASY" as const,
      order: 2,
    },
    {
      deckId: deck.id,
      front: "Which beta-blocker is safest for COPD patients?",
      back: "Bisoprolol",
      explanation: "Highly selective β1-blocker with minimal β2 activity. Non-selective beta-blockers like propranolol can cause bronchospasm.",
      difficulty: "HARD" as const,
      order: 3,
    },
    {
      deckId: deck.id,
      front: "What is the mechanism of Furosemide?",
      back: "Inhibition of Na+-K+-2Cl- cotransporter (NKCC2) in the thick ascending limb of Loop of Henle",
      explanation: "Loop diuretic. Most potent diuretic class. Causes hypokalemia, hypomagnesemia, and ototoxicity at high doses.",
      difficulty: "MEDIUM" as const,
      order: 4,
    },
    {
      deckId: deck.id,
      front: "What is the antidote for acetaminophen (paracetamol) overdose?",
      back: "N-acetylcysteine (NAC)",
      explanation: "Replenishes glutathione stores, preventing hepatic necrosis. Most effective within 8 hours of ingestion.",
      difficulty: "EASY" as const,
      order: 5,
    },
  ];

  for (const card of flashcards) {
    await prisma.flashcard.create({ data: card });
  }

  // Create Subscription Plans
  const plans = [
    {
      name: "Free",
      priceEgp: 0,
      priceUsd: 0,
      billingInterval: "MONTHLY" as const,
      features: [
        { featureId: "content_library", name: "Full content library", included: true },
        { featureId: "mcq_limit", name: "50 MCQs per day", included: true },
        { featureId: "ai_limit", name: "10 AI messages per day", included: true },
        { featureId: "flashcards_basic", name: "Basic flashcards", included: true },
        { featureId: "community", name: "Community access", included: true },
        { featureId: "ai_predictor", name: "AI Exam Predictor", included: false },
        { featureId: "study_plans", name: "Smart study plans", included: false },
      ],
      isActive: true,
      trialDays: 0,
    },
    {
      name: "Premium Monthly",
      priceEgp: 149,
      priceUsd: 3,
      billingInterval: "MONTHLY" as const,
      features: [
        { featureId: "content_library", name: "Full content library", included: true },
        { featureId: "mcq_unlimited", name: "Unlimited MCQs", included: true },
        { featureId: "ai_unlimited", name: "Unlimited AI messages", included: true },
        { featureId: "ai_predictor", name: "AI Exam Predictor", included: true },
        { featureId: "study_plans", name: "Smart study plans", included: true },
        { featureId: "ai_flashcards", name: "AI-generated flashcards", included: true },
        { featureId: "priority_support", name: "Priority support", included: true },
      ],
      isActive: true,
      isPopular: true,
      trialDays: 7,
    },
    {
      name: "Premium Semester",
      priceEgp: 399,
      priceUsd: 8,
      billingInterval: "SEMESTER" as const,
      features: [
        { featureId: "everything_premium", name: "Everything in Premium", included: true },
        { featureId: "discount", name: "33% discount vs monthly", included: true },
        { featureId: "badge", name: "Exclusive Semester Saver badge", included: true },
        { featureId: "early_access", name: "Early access to features", included: true },
      ],
      isActive: true,
      trialDays: 7,
    },
  ];

  for (const plan of plans) {
    await prisma.subscriptionPlan.create({ data: plan });
  }

  // Create Content Items (sample PDFs)
  const contents = [
    {
      title: "Cardiac Cycle Lecture Slides - Week 3",
      description: "Dr. Ahmed's complete lecture on cardiac cycle mechanics",
      fileUrl: "https://storage.mti-hub.com/lectures/cardiac-cycle-week3.pdf",
      fileType: "PDF" as const,
      fileSize: 2450000,
      yearId: year2.id,
      courseId: cardiology.id,
      moduleId: cardiacCycle.id,
      uploadedBy: profAhmed.userId,
      uploadType: "PROFESSOR" as const,
      verificationStatus: "VERIFIED" as const,
    },
    {
      title: "Pharmacology Drug Summary - Cardiovascular",
      description: "Comprehensive summary of all cardiovascular drugs",
      fileUrl: "https://storage.mti-hub.com/notes/cardio-drugs-summary.pdf",
      fileType: "PDF" as const,
      fileSize: 1800000,
      yearId: year2.id,
      courseId: pharmacology.id,
      moduleId: cardioDrugs.id,
      uploadedBy: profSarah.userId,
      uploadType: "PROFESSOR" as const,
      verificationStatus: "VERIFIED" as const,
    },
  ];

  for (const content of contents) {
    await prisma.contentItem.create({ data: content });
  }

  // Create Exams
  const exams = [
    {
      title: "Pharmacology Midterm",
      courseId: pharmacology.id,
      examDate: new Date("2026-08-22T09:00:00Z"),
      duration: 120,
      location: "Hall B",
      examType: "WRITTEN" as const,
      weight: 1,
    },
    {
      title: "Physiology Quiz 3",
      courseId: cardiology.id,
      examDate: new Date("2026-08-25T10:00:00Z"),
      duration: 45,
      location: "Online",
      examType: "QUIZ" as const,
      weight: 0.5,
    },
  ];

  for (const exam of exams) {
    await prisma.exam.create({ data: exam });
  }

  console.log("✅ Seeding completed successfully!");
  console.log(`   - ${await prisma.course.count()} courses created`);
  console.log(`   - ${await prisma.mcqQuestion.count()} MCQs created`);
  console.log(`   - ${await prisma.flashcard.count()} flashcards created`);
  console.log(`   - ${await prisma.subscriptionPlan.count()} plans created`);
  console.log(`   - ${await prisma.contentItem.count()} content items created`);
}

main()
  .catch((e) => {
    console.error("❌ Seeding failed:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
