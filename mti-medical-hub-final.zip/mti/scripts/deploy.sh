#!/bin/bash

# MTI Medical Hub Deployment Script
# Usage: ./scripts/deploy.sh [environment]
# Environment: dev (default) | staging | production

set -e

ENV=${1:-dev}
echo "🚀 Deploying MTI Medical Hub to $ENV environment..."

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check prerequisites
echo "📋 Checking prerequisites..."

if ! command -v node &> /dev/null; then
    echo "${RED}❌ Node.js is not installed. Please install Node.js 18+ first.${NC}"
    exit 1
fi

if ! command -v npm &> /dev/null; then
    echo "${RED}❌ npm is not installed.${NC}"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "${RED}❌ Node.js version must be 18 or higher. Current: $(node -v)${NC}"
    exit 1
fi

echo "${GREEN}✅ Node.js $(node -v) detected${NC}"

# Install dependencies
echo "📦 Installing dependencies..."
npm ci

# Generate Prisma client
echo "🔄 Generating Prisma client..."
npx prisma generate

# Run database migrations (only for staging/production)
if [ "$ENV" != "dev" ]; then
    echo "🗄️ Running database migrations..."
    npx prisma migrate deploy
fi

# Build application
echo "🏗️ Building application..."
npm run build

# Run tests (if any)
if [ "$ENV" = "production" ]; then
    echo "🧪 Running tests..."
    npm run lint
    # npm run test (when tests are added)
fi

# Deploy based on environment
case $ENV in
    dev)
        echo "${YELLOW}🖥️ Starting development server...${NC}"
        npm run dev
        ;;
    staging)
        echo "${YELLOW}🚀 Deploying to Vercel (staging)...${NC}"
        vercel --target=preview
        ;;
    production)
        echo "${YELLOW}🚀 Deploying to Vercel (production)...${NC}"
        vercel --prod
        ;;
    *)
        echo "${RED}❌ Unknown environment: $ENV${NC}"
        echo "Usage: ./scripts/deploy.sh [dev|staging|production]"
        exit 1
        ;;
esac

echo "${GREEN}✅ Deployment complete!${NC}"
