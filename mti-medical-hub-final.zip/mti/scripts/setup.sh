#!/bin/bash

# MTI Medical Hub Setup Script
# Run this after cloning the repo to set up your local environment

set -e

echo "🚀 Setting up MTI Medical Hub..."

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Check Node.js version
NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "❌ Node.js 18+ required. Current: $(node -v)"
    exit 1
fi

echo "${GREEN}✅ Node.js $(node -v) detected${NC}"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Set up environment file
if [ ! -f .env.local ]; then
    echo "📝 Creating .env.local from template..."
    cp .env.example .env.local
    echo "${YELLOW}⚠️ Please edit .env.local and add your API keys before running the app${NC}"
fi

# Generate Prisma client
echo "🔄 Generating Prisma client..."
npx prisma generate

# Set up database (if using local PostgreSQL via Docker)
if command -v docker &> /dev/null && command -v docker-compose &> /dev/null; then
    echo "🐳 Docker detected. Starting local database..."
    docker-compose up -d db redis

    # Wait for database to be ready
    echo "⏳ Waiting for database..."
    sleep 5

    # Update .env.local with local database URL
    if grep -q "DATABASE_URL="postgresql://" .env.local; then
        sed -i '' 's|DATABASE_URL=.*|DATABASE_URL="postgresql://postgres:postgres@localhost:5432/mti_hub"|' .env.local 2>/dev/null ||         sed -i 's|DATABASE_URL=.*|DATABASE_URL="postgresql://postgres:postgres@localhost:5432/mti_hub"|' .env.local
        sed -i '' 's|DIRECT_URL=.*|DIRECT_URL="postgresql://postgres:postgres@localhost:5432/mti_hub"|' .env.local 2>/dev/null ||         sed -i 's|DIRECT_URL=.*|DIRECT_URL="postgresql://postgres:postgres@localhost:5432/mti_hub"|' .env.local
    fi

    # Push schema and seed
    echo "🗄️ Setting up database..."
    npx prisma db push
    npx prisma db seed

    echo "${GREEN}✅ Local database ready with seed data!${NC}"
else
    echo "${YELLOW}⚠️ Docker not found. Skipping local database setup.${NC}"
    echo "   Please configure DATABASE_URL in .env.local manually."
fi

echo ""
echo "${GREEN}✅ Setup complete!${NC}"
echo ""
echo "Next steps:"
echo "1. Edit .env.local with your API keys"
echo "2. Run: npm run dev"
echo "3. Open: http://localhost:3000"
