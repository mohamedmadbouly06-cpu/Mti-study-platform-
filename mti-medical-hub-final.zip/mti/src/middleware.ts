import { auth } from "@/lib/auth";

export default auth((req) => {
  const { nextUrl } = req;
  const isLoggedIn = !!req.auth;
  const isApiAuthRoute = nextUrl.pathname.startsWith("/api/auth");
  const isPublicRoute = ["/", "/pricing", "/auth/signin"].includes(nextUrl.pathname);
  const isApiRoute = nextUrl.pathname.startsWith("/api");

  if (isApiAuthRoute) return null;
  if (isApiRoute) return null; // API routes handle their own auth
  if (isPublicRoute) return null;

  if (!isLoggedIn) {
    return Response.redirect(new URL("/auth/signin", nextUrl));
  }

  return null;
});

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\.(?:svg|png|jpg|jpeg|gif|webp)$).*)"],
};
