"use client";

import { cn } from "@/lib/utils";
import { CheckCircle2, Circle, Play, BookOpen } from "lucide-react";
import Link from "next/link";

interface RoadmapItem {
  id: string;
  title: string;
  course: string;
  duration: string;
  completed: boolean;
  xp: number;
  recommended?: boolean;
  cardsDue?: number;
  source?: string;
}

interface DailyRoadmapProps {
  items: RoadmapItem[];
  className?: string;
}

export function DailyRoadmap({ items, className }: DailyRoadmapProps) {
  const completedCount = items.filter(i => i.completed).length;
  const remainingCount = items.length - completedCount;

  return (
    <div className={cn("bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden", className)}>
      <div className="p-6 border-b border-slate-100 flex items-center justify-between">
        <div>
          <h3 className="text-lg font-bold text-slate-900">Today&apos;s Study Roadmap</h3>
          <p className="text-sm text-slate-500">
            {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })} 
            {" "}• {remainingCount} tasks remaining
          </p>
        </div>
        <Link
          href="/courses"
          className="bg-teal-600 text-white px-5 py-2.5 rounded-xl text-sm font-bold hover:bg-teal-700 transition-colors shadow-lg shadow-teal-600/20"
        >
          Start Focus Mode
        </Link>
      </div>
      <div className="divide-y divide-slate-100">
        {items.map((item, index) => (
          <div 
            key={item.id}
            className={cn(
              "p-6 flex items-center gap-4 transition-colors cursor-pointer group",
              item.completed ? "bg-slate-50/50" : "hover:bg-slate-50"
            )}
          >
            <div className={cn(
              "w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0",
              item.completed 
                ? "bg-teal-100 text-teal-600" 
                : item.recommended 
                  ? "bg-amber-100 text-amber-600 border-2 border-amber-300"
                  : "bg-slate-100 text-slate-400 border-2 border-slate-200"
            )}>
              {item.completed ? (
                <CheckCircle2 className="w-5 h-5" />
              ) : (
                <span className="text-sm font-bold">{index + 1}</span>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className={cn(
                "font-semibold transition-colors",
                item.completed ? "text-slate-400 line-through" : "text-slate-900 group-hover:text-teal-600"
              )}>
                {item.title}
              </p>
              <p className="text-sm text-slate-500 mt-0.5">
                {item.course} • {item.duration}
                {item.source && ` • ${item.source}`}
                {item.cardsDue && ` • ${item.cardsDue} cards due`}
              </p>
            </div>
            {!item.completed && (
              <>
                <span className="text-xs font-bold text-teal-600 bg-teal-50 px-3 py-1 rounded-full">
                  +{item.xp} XP
                </span>
                {item.recommended && (
                  <Link 
                    href={item.title.includes("MCQ") ? "/mcq" : item.title.includes("Flashcard") ? "/flashcards" : "/courses"}
                    className="opacity-0 group-hover:opacity-100 transition-opacity bg-teal-600 text-white px-4 py-2 rounded-lg text-sm font-bold"
                  >
                    Start
                  </Link>
                )}
              </>
            )}
            {item.completed && (
              <span className="text-xs font-bold text-teal-600 bg-teal-50 px-3 py-1 rounded-full">
                +{item.xp} XP
              </span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
