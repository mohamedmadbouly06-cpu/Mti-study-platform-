"use client";

import { cn } from "@/lib/utils";
import { Flame, Zap } from "lucide-react";

interface StreakCardProps {
  streak: number;
  xp: number;
  className?: string;
}

export function StreakCard({ streak, xp, className }: StreakCardProps) {
  return (
    <div className={cn("flex items-center gap-4", className)}>
      <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 px-4 py-2 rounded-xl">
        <Flame className="w-6 h-6 text-amber-500" />
        <div>
          <p className="text-xs text-amber-600 font-bold uppercase tracking-wider">Streak</p>
          <p className="text-xl font-black text-amber-700">{streak} days</p>
        </div>
      </div>
      <div className="flex items-center gap-2 bg-violet-50 border border-violet-200 px-4 py-2 rounded-xl">
        <Zap className="w-6 h-6 text-violet-500" />
        <div>
          <p className="text-xs text-violet-600 font-bold uppercase tracking-wider">XP</p>
          <p className="text-xl font-black text-violet-700">{xp.toLocaleString()}</p>
        </div>
      </div>
    </div>
  );
}
