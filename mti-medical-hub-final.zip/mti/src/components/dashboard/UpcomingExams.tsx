"use client";

import { cn } from "@/lib/utils";
import { Calendar, MapPin } from "lucide-react";

interface Exam {
  id: string;
  title: string;
  date: string;
  location: string;
  type: "URGENT" | "NORMAL";
  daysLeft: number;
}

interface UpcomingExamsProps {
  exams: Exam[];
  className?: string;
}

export function UpcomingExams({ exams, className }: UpcomingExamsProps) {
  return (
    <div className={cn("bg-white rounded-2xl border border-slate-200 shadow-sm p-6", className)}>
      <h3 className="text-lg font-bold text-slate-900 mb-4">Upcoming</h3>
      <div className="space-y-3">
        {exams.map((exam) => (
          <div 
            key={exam.id} 
            className={cn(
              "flex items-center gap-4 p-3 rounded-xl border",
              exam.type === "URGENT" ? "bg-red-50 border-red-100" : "bg-slate-50 border-slate-100"
            )}
          >
            <div className={cn(
              "w-12 h-12 rounded-xl flex items-center justify-center font-bold text-sm",
              exam.type === "URGENT" ? "bg-red-100 text-red-600" : "bg-slate-100 text-slate-600"
            )}>
              {new Date(exam.date).toLocaleDateString("en-US", { month: "short" }).toUpperCase()}
              <br />
              {new Date(exam.date).getDate()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-bold text-slate-900 truncate">{exam.title}</p>
              <p className="text-sm text-slate-500 flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                {exam.daysLeft} days remaining
                <span className="mx-1">•</span>
                <MapPin className="w-3 h-3" />
                {exam.location}
              </p>
            </div>
            {exam.type === "URGENT" && (
              <span className="text-xs font-bold text-red-600 bg-red-100 px-3 py-1 rounded-full flex-shrink-0">
                URGENT
              </span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
