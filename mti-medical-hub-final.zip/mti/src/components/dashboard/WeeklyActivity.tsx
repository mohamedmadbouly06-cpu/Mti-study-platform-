"use client";

import { cn } from "@/lib/utils";

interface DayData {
  day: string;
  minutes: number;
  maxMinutes: number;
}

interface WeeklyActivityProps {
  data: DayData[];
  className?: string;
}

export function WeeklyActivity({ data, className }: WeeklyActivityProps) {
  const maxValue = Math.max(...data.map(d => d.minutes), 1);

  return (
    <div className={cn("bg-white rounded-2xl border border-slate-200 shadow-sm p-6", className)}>
      <h3 className="text-lg font-bold text-slate-900 mb-4">Weekly Activity</h3>
      <div className="flex items-end justify-between h-32 gap-2">
        {data.map((item) => {
          const heightPercent = (item.minutes / maxValue) * 100;
          const isToday = item.day === new Date().toLocaleDateString("en-US", { weekday: "short" }).slice(0, 3);

          return (
            <div key={item.day} className="flex-1 flex flex-col items-center gap-2">
              <div className="w-full bg-slate-100 rounded-t-lg relative" style={{ height: "100%" }}>
                <div 
                  className={cn(
                    "absolute bottom-0 w-full rounded-t-lg transition-all duration-500",
                    isToday ? "bg-teal-500" : "bg-teal-400/70"
                  )}
                  style={{ height: `${heightPercent}%` }}
                />
              </div>
              <span className={cn("text-xs font-medium", isToday ? "text-teal-700 font-bold" : "text-slate-500")}>
                {item.day}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
