"use client";

import { ProgressRing } from "@/components/ui/ProgressRing";
import { cn } from "@/lib/utils";

interface Goal {
  label: string;
  current: number;
  target: number;
  unit: string;
  color: string;
}

interface DailyGoalsProps {
  goals: Goal[];
  className?: string;
}

export function DailyGoals({ goals, className }: DailyGoalsProps) {
  return (
    <div className={cn("grid grid-cols-1 md:grid-cols-3 gap-4", className)}>
      {goals.map((goal) => {
        const percentage = Math.round((goal.current / goal.target) * 100);
        const isComplete = percentage >= 100;

        return (
          <div 
            key={goal.label} 
            className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-semibold text-slate-600">{goal.label}</span>
              <span className={cn(
                "text-xs font-bold px-2 py-1 rounded-lg",
                isComplete ? "bg-teal-50 text-teal-600" : "bg-slate-50 text-slate-400"
              )}>
                {goal.current}/{goal.target} {goal.unit}
              </span>
            </div>
            <div className="flex justify-center">
              <ProgressRing 
                progress={percentage} 
                size={96} 
                color={isComplete ? "#0d9488" : "#cbd5e1"}
              >
                <span className={cn("text-lg font-bold", isComplete ? "text-teal-700" : "text-slate-400")}>
                  {percentage}%
                </span>
              </ProgressRing>
            </div>
          </div>
        );
      })}
    </div>
  );
}
