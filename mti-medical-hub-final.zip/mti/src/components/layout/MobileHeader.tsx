"use client";

import { useState } from "react";
import { Menu } from "lucide-react";

export function MobileHeader() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-white border-b border-slate-200 z-40 flex items-center justify-between px-4">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-lg bg-teal-600 flex items-center justify-center text-white font-bold">M</div>
        <span className="font-bold text-slate-900">MTI Hub</span>
      </div>
      <button 
        onClick={() => {
          setIsOpen(!isOpen);
          // Dispatch custom event to toggle sidebar
          window.dispatchEvent(new CustomEvent("toggle-sidebar"));
        }} 
        className="p-2 rounded-lg hover:bg-slate-100"
      >
        <Menu className="w-6 h-6 text-slate-600" />
      </button>
    </header>
  );
}
