"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";
import { ArrowLeft, CheckCircle2, XCircle, Zap } from "lucide-react";

interface McqOption {
  id: string;
  text: string;
  isCorrect: boolean;
}

interface McqQuestion {
  id: string;
  topic: string;
  question: string;
  options: McqOption[];
  explanation: string;
}

interface McqSessionProps {
  questions: McqQuestion[];
  onComplete: (results: { correct: number; total: number; xp: number }) => void;
  onExit: () => void;
}

export function McqSession({ questions, onComplete, onExit }: McqSessionProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [answers, setAnswers] = useState<{ questionId: string; correct: boolean }[]>([]);

  const currentQuestion = questions[currentIndex];
  const progress = ((currentIndex + (showExplanation ? 1 : 0)) / questions.length) * 100;

  const handleSelectOption = (optionId: string) => {
    if (showExplanation) return;
    setSelectedOption(optionId);
    setShowExplanation(true);

    const isCorrect = currentQuestion.options.find(o => o.id === optionId)?.isCorrect ?? false;
    setAnswers(prev => [...prev, { questionId: currentQuestion.id, correct: isCorrect }]);
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setSelectedOption(null);
      setShowExplanation(false);
    } else {
      const correct = answers.filter(a => a.correct).length;
      const xp = correct * 30 + (correct === questions.length ? 50 : 0); // Bonus for perfect score
      onComplete({ correct, total: questions.length, xp });
    }
  };

  const selectedOptionData = currentQuestion.options.find(o => o.id === selectedOption);
  const isCorrect = selectedOptionData?.isCorrect ?? false;

  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <button onClick={onExit} className="text-slate-500 hover:text-slate-700 text-sm font-medium flex items-center gap-2">
          <ArrowLeft className="w-4 h-4" />
          Exit Session
        </button>
        <div className="flex items-center gap-4">
          <span className="text-sm text-slate-500">
            Question <span className="font-bold text-slate-900">{currentIndex + 1}</span> / {questions.length}
          </span>
          <div className="w-32 bg-slate-200 rounded-full h-2">
            <div className="bg-teal-600 h-2 rounded-full transition-all duration-300" style={{ width: `${progress}%` }} />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-lg p-8">
        <div className="mb-2">
          <span className="text-xs font-bold text-teal-600 bg-teal-50 px-3 py-1 rounded-full">
            {currentQuestion.topic}
          </span>
        </div>
        <h3 className="text-xl font-bold text-slate-900 mb-6 leading-relaxed">
          {currentQuestion.question}
        </h3>

        <div className="space-y-3">
          {currentQuestion.options.map((option) => {
            const isSelected = selectedOption === option.id;
            const showCorrect = showExplanation && option.isCorrect;
            const showIncorrect = showExplanation && isSelected && !option.isCorrect;

            return (
              <button
                key={option.id}
                onClick={() => handleSelectOption(option.id)}
                disabled={showExplanation}
                className={cn(
                  "w-full text-left p-4 rounded-xl border-2 transition-all duration-200",
                  showCorrect 
                    ? "border-emerald-500 bg-emerald-50 text-emerald-900"
                    : showIncorrect
                      ? "border-red-500 bg-red-50 text-red-900"
                      : isSelected
                        ? "border-teal-500 bg-teal-50 text-teal-900"
                        : "border-slate-200 hover:border-teal-300 hover:bg-slate-50 text-slate-700"
                )}
              >
                <div className="flex items-center gap-3">
                  <span className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0",
                    showCorrect ? "bg-emerald-500 text-white" : 
                    showIncorrect ? "bg-red-500 text-white" :
                    isSelected ? "bg-teal-500 text-white" : "bg-slate-100 text-slate-600"
                  )}>
                    {showCorrect ? <CheckCircle2 className="w-5 h-5" /> : 
                     showIncorrect ? <XCircle className="w-5 h-5" /> :
                     String.fromCharCode(65 + currentQuestion.options.indexOf(option))}
                  </span>
                  <span className="font-medium">{option.text}</span>
                </div>
              </button>
            );
          })}
        </div>

        {showExplanation && (
          <div className={cn(
            "mt-6 p-4 rounded-xl border",
            isCorrect ? "bg-emerald-50 border-emerald-200" : "bg-red-50 border-red-200"
          )}>
            <div className="flex items-start gap-3">
              <div className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0",
                isCorrect ? "bg-emerald-500 text-white" : "bg-red-500 text-white"
              )}>
                {isCorrect ? <CheckCircle2 className="w-5 h-5" /> : <XCircle className="w-5 h-5" />}
              </div>
              <div>
                <p className={cn("font-bold mb-1", isCorrect ? "text-emerald-800" : "text-red-800")}>
                  {isCorrect ? "Correct! Great job!" : "Not quite. Here's why:"}
                </p>
                <p className="text-sm text-slate-600 leading-relaxed">{currentQuestion.explanation}</p>
                <button className="mt-3 text-sm text-teal-600 font-bold hover:text-teal-700 flex items-center gap-1">
                  <Zap className="w-4 h-4" />
                  Ask AI Tutor about this
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="mt-6 flex justify-end">
          {showExplanation && (
            <button 
              onClick={handleNext}
              className="bg-teal-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-teal-700 transition-all shadow-lg shadow-teal-600/20"
            >
              {currentIndex < questions.length - 1 ? "Next Question →" : "Finish Session →"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
