"use client";

import { cn } from "@/lib/utils";
import { Flame, Trophy } from "lucide-react";

interface McqTopic {
  id: string;
  name: string;
  icon: string;
  color: string;
  questionCount: number;
  avgScore: number;
  easyCount: number;
  hardCount: number;
}

interface McqLobbyProps {
  topics: McqTopic[];
  streak: number;
  weeklyProgress: number;
  weeklyTarget: number;
  onStartSession: (topicId: string) => void;
  className?: string;
}

export function McqLobby({ topics, streak, weeklyProgress, weeklyTarget, onStartSession, className }: McqLobbyProps) {
  return (
    <div className={cn("space-y-6", className)}>
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">MCQ Bank</h2>
          <p className="text-slate-500 mt-1">1,247 verified questions • 342 contributed by students</p>
        </div>
        <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 px-4 py-2 rounded-xl">
          <Flame className="w-5 h-5 text-amber-500" />
          <span className="text-sm font-bold text-amber-700">Daily Streak: {streak}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {topics.map((topic) => (
          <button
            key={topic.id}
            onClick={() => onStartSession(topic.id)}
            className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 text-left hover:border-teal-300 hover:shadow-md transition-all"
          >
            <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center mb-3 text-2xl">
              {topic.icon}
            </div>
            <h3 className="font-bold text-slate-900">{topic.name}</h3>
            <p className="text-sm text-slate-500 mt-1">{topic.questionCount} questions • {topic.avgScore}% avg score</p>
            <div className="mt-3 flex gap-2">
              <span className="text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded-lg">Easy: {topic.easyCount}</span>
              <span className="text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded-lg">Hard: {topic.hardCount}</span>
            </div>
          </button>
        ))}
      </div>

      <div className="bg-gradient-to-r from-teal-600 to-emerald-600 rounded-2xl p-6 text-white shadow-lg shadow-teal-600/20">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold">Weekly Challenge</h3>
            <p className="text-teal-100 text-sm mt-1">
              Complete {weeklyTarget} MCQs this week to earn the &quot;Centurion&quot; badge
            </p>
            <div className="mt-3 flex items-center gap-3">
              <div className="flex-1 bg-white/20 rounded-full h-3 max-w-xs">
                <div 
                  className="bg-white h-3 rounded-full transition-all duration-500" 
                  style={{ width: `${(weeklyProgress / weeklyTarget) * 100}%` }}
                />
              </div>
              <span className="text-sm font-bold">{weeklyProgress}/{weeklyTarget}</span>
            </div>
          </div>
          <Trophy className="w-12 h-12 text-white/80" />
        </div>
      </div>
    </div>
  );
}
