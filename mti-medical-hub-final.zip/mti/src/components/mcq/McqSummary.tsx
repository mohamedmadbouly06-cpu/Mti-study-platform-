"use client";

import { ProgressRing } from "@/components/ui/ProgressRing";
import { Button } from "@/components/ui/Button";
import Link from "next/link";

interface McqSummaryProps {
  correct: number;
  total: number;
  xp: number;
  onRestart: () => void;
}

export function McqSummary({ correct, total, xp, onRestart }: McqSummaryProps) {
  const percentage = Math.round((correct / total) * 100);

  return (
    <div className="max-w-lg mx-auto text-center animate-fade-in">
      <div className="text-6xl mb-4">🎉</div>
      <h2 className="text-3xl font-black text-slate-900 mb-2">Session Complete!</h2>
      <p className="text-slate-500 mb-6">You crushed it! Here&apos;s how you performed:</p>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-lg p-8 mb-6">
        <div className="flex justify-center mb-4">
          <ProgressRing progress={percentage} size={128} strokeWidth={12}>
            <span className="text-3xl font-black text-slate-900">{percentage}%</span>
          </ProgressRing>
        </div>
        <p className="text-lg font-bold text-slate-900 mb-2">
          {correct} out of {total} correct
        </p>
        <p className="text-sm text-slate-500">+{xp} XP earned • +15 min study time</p>
      </div>

      <div className="flex gap-3 justify-center">
        <Button onClick={onRestart}>Start New Session</Button>
        <Link href="/">
          <Button variant="outline">Back to Dashboard</Button>
        </Link>
      </div>
    </div>
  );
}
