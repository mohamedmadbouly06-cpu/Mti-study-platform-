import NextAuth from "next-auth";
import Google from "next-auth/providers/google";
import { PrismaAdapter } from "@auth/prisma-adapter";
import { prisma } from "./prisma";

export const { handlers, signIn, signOut, auth } = NextAuth({
  adapter: PrismaAdapter(prisma),
  providers: [
    Google({
      clientId: process.env.AUTH_GOOGLE_ID!,
      clientSecret: process.env.AUTH_GOOGLE_SECRET!,
    }),
  ],
  pages: {
    signIn: "/auth/signin",
  },
  session: {
    strategy: "jwt",
    maxAge: 30 * 24 * 60 * 60, // 30 days
  },
  callbacks: {
    async jwt({ token, user, trigger, session }) {
      if (user) {
        token.id = user.id;
        // Fetch user data from DB
        const dbUser = await prisma.user.findUnique({
          where: { id: user.id },
          select: { 
            isPremium: true, 
            currentStreak: true, 
            totalXp: true,
            role: true,
            yearId: true,
          },
        });
        token.isPremium = dbUser?.isPremium ?? false;
        token.streak = dbUser?.currentStreak ?? 0;
        token.xp = dbUser?.totalXp ?? 0;
        token.role = dbUser?.role ?? "STUDENT";
      }

      if (trigger === "update" && session) {
        token.isPremium = session.isPremium ?? token.isPremium;
      }

      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.id as string;
        (session.user as any).isPremium = token.isPremium as boolean;
        (session.user as any).streak = token.streak as number;
        (session.user as any).xp = token.xp as number;
        (session.user as any).role = token.role as string;
      }
      return session;
    },
  },
  events: {
    async signIn({ user, isNewUser }) {
      if (isNewUser) {
        // Initialize user streak record
        await prisma.userStreak.upsert({
          where: { userId: user.id },
          create: {
            userId: user.id,
            currentStreak: 0,
            longestStreak: 0,
          },
          update: {},
        });
      }
    },
  },
});
