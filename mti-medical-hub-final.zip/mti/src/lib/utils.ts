import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date | string): string {
  return new Date(date).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export function formatRelativeTime(date: Date | string): string {
  const now = new Date();
  const then = new Date(date);
  const diffInSeconds = Math.floor((now.getTime() - then.getTime()) / 1000);

  if (diffInSeconds < 60) return "just now";
  if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
  if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
  if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)}d ago`;
  return formatDate(date);
}

export function calculateStreak(lastStudyDate: Date | null, currentStreak: number): number {
  if (!lastStudyDate) return 0;

  const lastDate = new Date(lastStudyDate);
  lastDate.setHours(0, 0, 0, 0);

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);

  const diffDays = Math.floor((today.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));

  if (diffDays === 0) return currentStreak;
  if (diffDays === 1) return currentStreak;
  return 0;
}

export function generateXP(studyMinutes: number, mcqCorrect: number, flashcardsReviewed: number): number {
  return Math.floor(studyMinutes * 2 + mcqCorrect * 10 + flashcardsReviewed * 5);
}

export function getLevelFromXP(xp: number): { level: number; title: string; nextLevelXP: number } {
  const level = Math.floor(xp / 1000) + 1;
  const titles = [
    "Medical Novice", "Anatomy Apprentice", "Histology Hero",
    "Physiology Prodigy", "Biochemistry Brain", "Pathology Pioneer",
    "Pharmacology Phantom", "Clinical Champion", "Diagnostic Deity", "Medical Master"
  ];
  return {
    level,
    title: titles[Math.min(level - 1, titles.length - 1)],
    nextLevelXP: level * 1000,
  };
}
