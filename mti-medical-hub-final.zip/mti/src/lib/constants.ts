export const APP_NAME = "MTI Medical Hub";
export const APP_TAGLINE = "The Student Operating System for Medical Students";

export const FREE_PLAN_LIMITS = {
  mcqPerDay: 50,
  aiMessagesPerDay: 10,
  flashcardsPerDay: 30,
  downloadsPerDay: 5,
};

export const PREMIUM_FEATURES = [
  "Unlimited MCQs",
  "Unlimited AI Tutor messages",
  "AI Exam Predictor",
  "Smart Study Plans",
  "AI-generated flashcards",
  "Priority support",
  "Ad-free experience",
  "Advanced analytics",
];

export const SUBSCRIPTION_PLANS = [
  {
    id: "free",
    name: "Free",
    priceEgp: 0,
    priceUsd: 0,
    interval: "month",
    features: [
      "Full content library",
      "50 MCQs per day",
      "10 AI messages per day",
      "Basic flashcards",
      "Community access",
    ],
  },
  {
    id: "premium_monthly",
    name: "Premium Monthly",
    priceEgp: 149,
    priceUsd: 3,
    interval: "month",
    popular: true,
    features: [
      "Everything in Free",
      "Unlimited MCQs",
      "Unlimited AI messages",
      "AI Exam Predictor",
      "Smart study plans",
      "AI-generated flashcards",
      "Priority support",
    ],
  },
  {
    id: "premium_semester",
    name: "Premium Semester",
    priceEgp: 399,
    priceUsd: 8,
    interval: "semester",
    features: [
      "Everything in Premium",
      "33% discount vs monthly",
      "Exclusive Semester Saver badge",
      "Early access to features",
    ],
  },
];

export const COURSES = [
  { id: "cardiology", name: "Cardiology", icon: "🫀", color: "rose", professor: "Dr. Ahmed", progress: 67, totalLectures: 24, totalPdfs: 12 },
  { id: "pharmacology", name: "Pharmacology", icon: "💊", color: "violet", professor: "Dr. Sarah", progress: 42, totalLectures: 18, totalPdfs: 8 },
  { id: "neurology", name: "Neurology", icon: "🧠", color: "emerald", professor: "Dr. Hassan", progress: 89, totalLectures: 20, totalPdfs: 15 },
  { id: "pulmonology", name: "Pulmonology", icon: "🫁", color: "amber", professor: "Dr. Mona", progress: 0, totalLectures: 16, totalPdfs: 10 },
  { id: "gastroenterology", name: "Gastroenterology", icon: "🍎", color: "orange", professor: "Dr. Karim", progress: 15, totalLectures: 22, totalPdfs: 11 },
  { id: "nephrology", name: "Nephrology", icon: "💧", color: "cyan", professor: "Dr. Layla", progress: 0, totalLectures: 14, totalPdfs: 7 },
];

export const UPCOMING_EXAMS = [
  { id: "1", title: "Pharmacology Midterm", date: "2026-08-22", location: "Hall B", type: "URGENT", daysLeft: 7 },
  { id: "2", title: "Physiology Quiz 3", date: "2026-08-25", location: "Online", type: "NORMAL", daysLeft: 10 },
  { id: "3", title: "Anatomy Practical", date: "2026-09-02", location: "Lab 3", type: "NORMAL", daysLeft: 18 },
] as const;

export const DAILY_ROADMAP = [
  { id: "1", title: "Review Cardiac Cycle Lecture", course: "Pharmacology", duration: "30 min", completed: true, xp: 50, time: "9:30 AM" },
  { id: "2", title: "Complete 20 MCQs on Autonomic Nervous System", course: "Pharmacology", duration: "20 min", completed: false, xp: 100, recommended: true },
  { id: "3", title: "Review Flashcards: Cardiac Drugs", course: "Pharmacology", duration: "15 min", completed: false, xp: 75, cardsDue: 47 },
  { id: "4", title: "Read: Antiarrhythmic Drugs Summary", course: "Pharmacology", duration: "10 min", completed: false, xp: 40, source: "Dr. Sarah's notes" },
];

export const LEADERBOARD_DATA = [
  { rank: 1, name: "You", initials: "YO", avatar: "👑", xp: 3850, isCurrentUser: true },
  { rank: 2, name: "Ahmed K.", initials: "AK", avatar: "🥈", xp: 3240, isCurrentUser: false },
  { rank: 3, name: "Sara M.", initials: "SM", avatar: "🥉", xp: 2980, isCurrentUser: false },
  { rank: 4, name: "Mohamed K.", initials: "MK", avatar: null, xp: 2650, isCurrentUser: false },
  { rank: 5, name: "Nour A.", initials: "NA", avatar: null, xp: 2410, isCurrentUser: false },
  { rank: 6, name: "Youssef H.", initials: "YH", avatar: null, xp: 2200, isCurrentUser: false },
];
