"use client";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/Button";
import { Check, X, Sparkles } from "lucide-react";
import { SUBSCRIPTION_PLANS } from "@/lib/constants";

export default function PricingPage() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-slate-900">Choose Your Plan</h2>
        <p className="text-slate-500 mt-1">Join 1,247 MTI students who upgraded their study game</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
        {SUBSCRIPTION_PLANS.map((plan) => (
          <div 
            key={plan.id}
            className={cn(
              "bg-white rounded-2xl border shadow-sm p-6 transition-all hover:shadow-md",
              plan.popular ? "border-2 border-teal-500 shadow-xl shadow-teal-500/10 scale-105 relative" : "border-slate-200"
            )}
          >
            {plan.popular && (
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-teal-600 to-emerald-600 text-white text-xs font-bold px-4 py-1 rounded-full shadow-lg">
                MOST POPULAR
              </div>
            )}

            <div className="mb-6">
              <h3 className="text-lg font-bold text-slate-900">{plan.name}</h3>
              <p className="text-slate-500 text-sm mt-1">
                {plan.id === "free" ? "For casual studying" : plan.id.includes("semester") ? "Best value for serious students" : "For serious students"}
              </p>
              <div className="mt-4">
                <span className="text-3xl font-black text-slate-900">
                  {plan.priceEgp === 0 ? "Free" : plan.priceEgp}
                </span>
                {plan.priceEgp > 0 && (
                  <span className="text-slate-500"> EGP/{plan.interval === "semester" ? "4 months" : "month"}</span>
                )}
              </div>
            </div>

            <ul className="space-y-3 mb-6">
              {plan.features.map((feature, i) => (
                <li key={i} className="flex items-center gap-3 text-sm text-slate-600">
                  <Check className="w-5 h-5 text-teal-500 flex-shrink-0" />
                  {feature}
                </li>
              ))}
            </ul>

            <Button 
              variant={plan.id === "free" ? "outline" : "primary"}
              className="w-full"
              disabled={plan.id === "free"}
            >
              {plan.id === "free" ? "Current Plan" : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Upgrade Now
                </>
              )}
            </Button>
          </div>
        ))}
      </div>

      {/* Payment Methods */}
      <div className="max-w-2xl mx-auto bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
        <h3 className="text-lg font-bold text-slate-900 mb-4 text-center">Payment Methods</h3>
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center p-4 rounded-xl bg-slate-50 border border-slate-100">
            <div className="text-2xl mb-2">💳</div>
            <p className="text-sm font-bold text-slate-700">Credit Card</p>
            <p className="text-xs text-slate-500">Visa, Mastercard</p>
          </div>
          <div className="text-center p-4 rounded-xl bg-slate-50 border border-slate-100">
            <div className="text-2xl mb-2">🏪</div>
            <p className="text-sm font-bold text-slate-700">Fawry</p>
            <p className="text-xs text-slate-500">Cash at 100,000+ locations</p>
          </div>
          <div className="text-center p-4 rounded-xl bg-slate-50 border border-slate-100">
            <div className="text-2xl mb-2">📱</div>
            <p className="text-sm font-bold text-slate-700">Mobile Wallet</p>
            <p className="text-xs text-slate-500">Vodafone Cash</p>
          </div>
        </div>
      </div>
    </div>
  );
}
