"use client";

import { useState } from "react";
import { McqLobby } from "@/components/mcq/McqLobby";
import { McqSession } from "@/components/mcq/McqSession";
import { McqSummary } from "@/components/mcq/McqSummary";

const MCQ_TOPICS = [
  { id: "cardiology", name: "Cardiology", icon: "🫀", color: "rose", questionCount: 312, avgScore: 78, easyCount: 45, hardCount: 89 },
  { id: "pharmacology", name: "Pharmacology", icon: "💊", color: "violet", questionCount: 428, avgScore: 65, easyCount: 67, hardCount: 134 },
  { id: "neurology", name: "Neurology", icon: "🧠", color: "emerald", questionCount: 289, avgScore: 71, easyCount: 34, hardCount: 98 },
];

const SAMPLE_QUESTIONS = [
  {
    id: "q1",
    topic: "Pharmacology",
    question: "Which of the following is the primary mechanism of action of Aspirin?",
    options: [
      { id: "a", text: "Reversible inhibition of COX enzymes", isCorrect: false },
      { id: "b", text: "Irreversible inhibition of COX-1 and COX-2 enzymes", isCorrect: true },
      { id: "c", text: "Selective inhibition of COX-2 only", isCorrect: false },
      { id: "d", text: "Inhibition of lipoxygenase pathway", isCorrect: false },
      { id: "e", text: "Blockade of prostaglandin receptors", isCorrect: false },
    ],
    explanation: "Aspirin works by irreversibly acetylating serine residues in the active site of both COX-1 and COX-2 enzymes. This permanently inactivates the enzymes, unlike other NSAIDs which are reversible inhibitors. This explains why aspirin's antiplatelet effect lasts for the lifetime of the platelet (7-10 days).",
  },
  {
    id: "q2",
    topic: "Pharmacology",
    question: "A patient on warfarin therapy requires antibiotic treatment. Which antibiotic is MOST likely to increase warfarin's anticoagulant effect?",
    options: [
      { id: "a", text: "Azithromycin", isCorrect: false },
      { id: "b", text: "Ciprofloxacin", isCorrect: true },
      { id: "c", text: "Doxycycline", isCorrect: false },
      { id: "d", text: "Nitrofurantoin", isCorrect: false },
      { id: "e", text: "Fosfomycin", isCorrect: false },
    ],
    explanation: "Ciprofloxacin (a fluoroquinolone) inhibits CYP1A2 and can displace warfarin from protein binding sites, significantly increasing INR. Metronidazole and trimethoprim-sulfamethoxazole also have strong interactions. Always monitor INR closely when starting antibiotics in patients on warfarin.",
  },
  {
    id: "q3",
    topic: "Pharmacology",
    question: "Which beta-blocker is most suitable for a patient with both hypertension and chronic obstructive pulmonary disease (COPD)?",
    options: [
      { id: "a", text: "Propranolol", isCorrect: false },
      { id: "b", text: "Nadolol", isCorrect: false },
      { id: "c", text: "Metoprolol", isCorrect: false },
      { id: "d", text: "Carvedilol", isCorrect: false },
      { id: "e", text: "Bisoprolol", isCorrect: true },
    ],
    explanation: "Bisoprolol is a highly selective β1-blocker with minimal β2 activity, making it safer for COPD patients. While metoprolol is also β1-selective, bisoprolol has the highest β1/β2 selectivity ratio. Non-selective beta-blockers like propranolol can cause bronchospasm and are contraindicated in COPD.",
  },
  {
    id: "q4",
    topic: "Pharmacology",
    question: "The therapeutic index of a drug is defined as:",
    options: [
      { id: "a", text: "ED50 / LD50", isCorrect: false },
      { id: "b", text: "LD50 / ED50", isCorrect: true },
      { id: "c", text: "LD1 / ED99", isCorrect: false },
      { id: "d", text: "ED99 / LD1", isCorrect: false },
      { id: "e", text: "LD50 - ED50", isCorrect: false },
    ],
    explanation: "Therapeutic Index (TI) = LD50 / ED50. It measures drug safety - a higher TI indicates a safer drug (wider margin between toxic and effective doses). For example, digoxin has a low TI (2-3) requiring careful monitoring, while penicillin has a very high TI.",
  },
  {
    id: "q5",
    topic: "Pharmacology",
    question: "Which of the following is a potassium-sparing diuretic that acts as a competitive antagonist of aldosterone?",
    options: [
      { id: "a", text: "Furosemide", isCorrect: false },
      { id: "b", text: "Hydrochlorothiazide", isCorrect: false },
      { id: "c", text: "Spironolactone", isCorrect: true },
      { id: "d", text: "Acetazolamide", isCorrect: false },
      { id: "e", text: "Mannitol", isCorrect: false },
    ],
    explanation: "Spironolactone is a competitive antagonist of aldosterone at mineralocorticoid receptors in the distal convoluted tubule. It reduces Na+ reabsorption and K+ excretion, making it 'potassium-sparing.' It's used in heart failure, ascites, and as an antiandrogen. Watch for hyperkalemia, especially with ACE inhibitors.",
  },
];

type McqView = "lobby" | "session" | "summary";

export default function McqPage() {
  const [view, setView] = useState<McqView>("lobby");
  const [sessionResults, setSessionResults] = useState({ correct: 0, total: 0, xp: 0 });

  const handleStartSession = () => {
    setView("session");
  };

  const handleComplete = (results: { correct: number; total: number; xp: number }) => {
    setSessionResults(results);
    setView("summary");
  };

  const handleExit = () => {
    setView("lobby");
  };

  const handleRestart = () => {
    setView("lobby");
  };

  return (
    <div className="animate-fade-in">
      {view === "lobby" && (
        <McqLobby 
          topics={MCQ_TOPICS} 
          streak={12} 
          weeklyProgress={73} 
          weeklyTarget={100}
          onStartSession={handleStartSession}
        />
      )}
      {view === "session" && (
        <McqSession 
          questions={SAMPLE_QUESTIONS} 
          onComplete={handleComplete}
          onExit={handleExit}
        />
      )}
      {view === "summary" && (
        <McqSummary 
          correct={sessionResults.correct}
          total={sessionResults.total}
          xp={sessionResults.xp}
          onRestart={handleRestart}
        />
      )}
    </div>
  );
}
