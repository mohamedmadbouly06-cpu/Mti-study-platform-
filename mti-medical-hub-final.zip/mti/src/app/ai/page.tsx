"use client";

import { useState, useRef, useEffect } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/Button";
import { Send, FileText, HelpCircle, Layers, Sparkles, Loader2 } from "lucide-react";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  isLoading?: boolean;
}

const SUGGESTED_PROMPTS = [
  "Explain the cardiac cycle like I'm a Year 1 student",
  "Predict 5 questions Dr. Ahmed might ask on the next Cardiology exam",
  "Create a 14-day study plan for my Pharmacology midterm",
];

export default function AiTutorPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content: "Hello Omar! I'm your AI tutor. I know every lecture, past exam, and study guide for MTI Year 2. What would you like to learn today?",
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (text?: string) => {
    const messageText = text || input;
    if (!messageText.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: messageText,
    };

    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    // Simulate AI response (in production, this calls the API)
    setTimeout(() => {
      const responses: Record<string, string> = {
        "cardiac cycle": `The cardiac cycle is the sequence of events that occurs from one heartbeat to the next. Let me break it down simply:

**1. Systole (Contraction)**
- The heart muscle contracts
- Blood is pumped out to the body and lungs

**2. Diastole (Relaxation)**
- The heart muscle relaxes
- Blood fills the chambers

**Key analogy:** Think of the heart like a sponge. When you squeeze it (systole), water comes out. When you release it (diastole), it soaks up more water.

**For your MTI exam:** Dr. Ahmed typically asks about:
- The pressure changes in each chamber
- The timing of valve openings/closings
- The relationship between ECG waves and mechanical events

Would you like me to generate 5 practice MCQs on this topic?`,
        "exam": `Based on Dr. Ahmed's past 3 Cardiology exams and his recent lecture emphasis, here are my top 5 predictions for your upcoming midterm:

**1. Cardiac Cycle Pressure Changes (High Confidence: 92%)**
- He asked this in 2023 and 2024
- Focus on: Atrial vs ventricular pressure during different phases

**2. ECG Interpretation (High Confidence: 88%)**
- Always includes one ECG strip
- Likely: Identifying arrhythmia type from a given strip

**3. Heart Failure Pathophysiology (Medium-High Confidence: 79%)**
- He spent 2 full lectures on this recently
- Focus on: Frank-Starling mechanism and compensation

**4. Antiarrhythmic Drug Classification (Medium Confidence: 71%)**
- Vaughan-Williams classification
- Know the mechanisms for Class I, II, III, and IV

**5. Valvular Heart Disease Murmurs (Medium Confidence: 65%)**
- Timing (systolic vs diastolic)
- Location of maximal intensity

**Study recommendation:** Focus on topics 1-3 first - they represent 60% of likely exam content.`,
        "study plan": `Here's your personalized 14-day Pharmacology study plan:

**Week 1: Foundation Building**
- Day 1-2: Autonomic Nervous System (cholinergic & adrenergic)
- Day 3-4: Cardiovascular Pharmacology (antiarrhythmics, antihypertensives)
- Day 5: Review + 50 MCQs
- Day 6-7: CNS Pharmacology (sedatives, antiepileptics, opioids)

**Week 2: Integration & Exam Prep**
- Day 8-9: Antimicrobials (mechanisms, spectra, resistance)
- Day 10: Chemotherapy & Immunosuppressants
- Day 11: Review weak topics (based on your MCQ performance)
- Day 12: Past exam practice (2023 + 2024)
- Day 13: Final review + AI-generated predicted questions
- Day 14: Light review only, rest well

**Daily targets:**
- 2 hours active study
- 30 MCQs
- 20 flashcards

I'll track your progress and adjust the plan based on your MCQ accuracy. Ready to start?`,
      };

      let responseText = `I understand your question. Let me provide a comprehensive explanation based on MTI's curriculum and Dr. Ahmed's teaching style.

**Key Points:**
1. This topic is frequently tested (appeared in 3 of the last 5 exams)
2. Focus on understanding mechanisms rather than memorization
3. Check the linked lecture slides for visual diagrams

Would you like me to generate practice questions on this topic?`;

      const lowerInput = messageText.toLowerCase();
      if (lowerInput.includes("cardiac cycle") || lowerInput.includes("heart cycle")) {
        responseText = responses["cardiac cycle"];
      } else if (lowerInput.includes("exam") || lowerInput.includes("predict")) {
        responseText = responses["exam"];
      } else if (lowerInput.includes("study plan") || lowerInput.includes("plan")) {
        responseText = responses["study plan"];
      }

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: responseText,
      };

      setMessages(prev => [...prev, assistantMessage]);
      setIsLoading(false);
    }, 1500);
  };

  return (
    <div className="space-y-6 h-[calc(100vh-180px)] animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">AI Tutor</h2>
          <p className="text-slate-500 mt-1">Your personal medical study assistant</p>
        </div>
        <div className="flex items-center gap-2 bg-violet-50 border border-violet-200 px-4 py-2 rounded-xl">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-sm font-bold text-violet-700">AI Online</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
        {/* Chat Area */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col h-full">
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.map((message) => (
              <div 
                key={message.id} 
                className={cn("flex gap-4", message.role === "user" && "flex-row-reverse")}
              >
                <div className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0",
                  message.role === "assistant" 
                    ? "bg-gradient-to-br from-violet-500 to-purple-600 text-white"
                    : "bg-teal-100 text-teal-700"
                )}>
                  {message.role === "assistant" ? "AI" : "YO"}
                </div>
                <div className={cn(
                  "rounded-2xl p-4 max-w-lg whitespace-pre-line",
                  message.role === "assistant" 
                    ? "bg-slate-50 rounded-tl-sm"
                    : "bg-teal-50 rounded-tr-sm"
                )}>
                  {message.isLoading ? (
                    <div className="flex items-center gap-2 text-slate-400">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span className="text-sm">AI is thinking...</span>
                    </div>
                  ) : (
                    <p className="text-slate-700 leading-relaxed text-sm">{message.content}</p>
                  )}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-4">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center text-xs font-bold text-white">
                  AI
                </div>
                <div className="bg-slate-50 rounded-2xl rounded-tl-sm p-4">
                  <div className="flex items-center gap-2 text-slate-400">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span className="text-sm">Analyzing MTI curriculum data...</span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="p-4 border-t border-slate-100">
            <div className="flex gap-3">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSend()}
                placeholder="Ask anything about your courses..."
                className="flex-1 px-4 py-3 rounded-xl border border-slate-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm"
              />
              <Button onClick={() => handleSend()} disabled={isLoading || !input.trim()}>
                <Send className="w-5 h-5" />
              </Button>
            </div>
            <p className="text-xs text-slate-400 mt-2 text-center">
              AI responses are for study purposes only. Always verify critical information with your professors.
            </p>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
            <h3 className="font-bold text-slate-900 mb-3">Quick Actions</h3>
            <div className="space-y-2">
              <button className="w-full text-left px-4 py-3 rounded-xl bg-slate-50 hover:bg-teal-50 hover:text-teal-700 transition-all text-sm font-medium flex items-center gap-3 text-slate-600">
                <FileText className="w-4 h-4" />
                Summarize last lecture
              </button>
              <button className="w-full text-left px-4 py-3 rounded-xl bg-slate-50 hover:bg-teal-50 hover:text-teal-700 transition-all text-sm font-medium flex items-center gap-3 text-slate-600">
                <HelpCircle className="w-4 h-4" />
                Generate MCQs from PDF
              </button>
              <button className="w-full text-left px-4 py-3 rounded-xl bg-slate-50 hover:bg-teal-50 hover:text-teal-700 transition-all text-sm font-medium flex items-center gap-3 text-slate-600">
                <Layers className="w-4 h-4" />
                Create flashcard deck
              </button>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
            <h3 className="font-bold text-slate-900 mb-3">Suggested Questions</h3>
            <div className="space-y-2">
              {SUGGESTED_PROMPTS.map((prompt, i) => (
                <button
                  key={i}
                  onClick={() => handleSend(prompt)}
                  className="w-full text-left px-3 py-2 rounded-lg bg-slate-50 hover:bg-teal-50 text-slate-600 hover:text-teal-700 transition-all text-xs font-medium border border-slate-100 hover:border-teal-200"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
            <h3 className="font-bold text-slate-900 mb-3">Usage</h3>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-500">Messages today</span>
              <span className="text-sm font-bold text-slate-900">8 / 20</span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-2">
              <div className="bg-violet-500 h-2 rounded-full transition-all duration-500" style={{ width: "40%" }} />
            </div>
            <p className="text-xs text-slate-400 mt-2">Upgrade to Premium for unlimited AI access</p>
          </div>
        </div>
      </div>
    </div>
  );
}
