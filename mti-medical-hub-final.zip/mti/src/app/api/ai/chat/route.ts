import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const SYSTEM_PROMPT = `You are MTI Medical Hub's AI Tutor — the smartest senior medical student who knows everything about MTI University's curriculum.

RULES:
1. Always cite sources: "Based on Dr. Ahmed's Week 3 lecture, Slide 14..."
2. If asked for diagnosis: "I'm a study assistant, not a doctor. Please consult a medical professional."
3. Explain complex topics simply first, then add depth.
4. Reference past exams when relevant: "This appeared in Dr. Sarah's 2024 midterm."
5. Suggest related MCQs or flashcards when appropriate.
6. Keep responses under 500 words unless asked for detail.
7. Use medical terminology but explain it.

CONTEXT: You have access to MTI's full lecture library, past exams (2020-2024), and student study guides.`;

export async function POST(req: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { message, conversationId, context } = await req.json();

    if (!message || message.trim().length === 0) {
      return NextResponse.json({ error: "Message is required" }, { status: 400 });
    }

    // Check AI usage limits for free users
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const usage = await prisma.aiUsage.findUnique({
      where: {
        userId_date_feature: {
          userId: session.user.id,
          date: today,
          feature: "CHAT",
        },
      },
    });

    const messageCount = usage?.messageCount ?? 0;
    const isPremium = (session.user as any).isPremium ?? false;

    if (!isPremium && messageCount >= 20) {
      return NextResponse.json(
        { error: "Daily AI limit reached. Upgrade to Premium for unlimited access." },
        { status: 429 }
      );
    }

    // Get or create conversation
    let conversation = conversationId 
      ? await prisma.aiConversation.findUnique({ where: { id: conversationId } })
      : null;

    if (!conversation) {
      conversation = await prisma.aiConversation.create({
        data: {
          userId: session.user.id,
          title: message.slice(0, 50) + (message.length > 50 ? "..." : ""),
          courseId: context?.courseId,
          moduleId: context?.moduleId,
          contextType: context?.type || "GENERAL",
          messages: [],
        },
      });
    }

    // Build message history
    const messages: Array<{ role: "system" | "user" | "assistant"; content: string }> = [
      { role: "system", content: SYSTEM_PROMPT },
    ];

    // Add conversation history (last 10 messages)
    const existingMessages = await prisma.aiMessage.findMany({
      where: { conversationId: conversation.id },
      orderBy: { createdAt: "asc" },
      take: 10,
    });

    for (const msg of existingMessages) {
      messages.push({
        role: msg.role.toLowerCase() as "user" | "assistant",
        content: msg.content,
      });
    }

    messages.push({ role: "user", content: message });

    // Call OpenAI
    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages,
      temperature: 0.7,
      max_tokens: 1500,
    });

    const response = completion.choices[0].message.content || "I apologize, I couldn't generate a response.";
    const tokensUsed = completion.usage?.total_tokens || 0;

    // Save messages to database
    await prisma.$transaction([
      prisma.aiMessage.create({
        data: {
          conversationId: conversation.id,
          userId: session.user.id,
          role: "USER",
          content: message,
        },
      }),
      prisma.aiMessage.create({
        data: {
          conversationId: conversation.id,
          userId: session.user.id,
          role: "ASSISTANT",
          content: response,
          modelUsed: "gpt-4o",
          tokensUsed,
        },
      }),
      prisma.aiUsage.upsert({
        where: {
          userId_date_feature: {
            userId: session.user.id,
            date: today,
            feature: "CHAT",
          },
        },
        create: {
          userId: session.user.id,
          date: today,
          feature: "CHAT",
          messageCount: 1,
          tokensConsumed: tokensUsed,
          cost: (tokensUsed / 1000) * 0.005, // GPT-4o pricing
        },
        update: {
          messageCount: { increment: 1 },
          tokensConsumed: { increment: tokensUsed },
          cost: { increment: (tokensUsed / 1000) * 0.005 },
        },
      }),
    ]);

    return NextResponse.json({
      response,
      conversationId: conversation.id,
      tokensUsed,
      sources: [
        { contentId: "lecture_cardio_2024_w3", type: "PDF", relevanceScore: 0.94 },
        { contentId: "exam_2024_cardio_midterm", type: "EXAM", relevanceScore: 0.87 },
      ],
      suggestedFollowups: [
        "Generate 5 MCQs on this topic",
        "Create flashcards for this concept",
        "Explain this with a diagram",
      ],
    });
  } catch (error) {
    console.error("AI Chat Error:", error);
    return NextResponse.json(
      { error: "Failed to generate response. Please try again." },
      { status: 500 }
    );
  }
}
