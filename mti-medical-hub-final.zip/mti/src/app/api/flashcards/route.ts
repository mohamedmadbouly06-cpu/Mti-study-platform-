import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";

// GET /api/flashcards/decks
export async function GET(req: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const courseId = searchParams.get("courseId");
    const mode = searchParams.get("mode") || "browse"; // "browse" or "review"

    if (mode === "review") {
      // Get cards due for review today
      const today = new Date();
      today.setHours(23, 59, 59, 999);

      const reviews = await prisma.flashcardReview.findMany({
        where: {
          userId: session.user.id,
          dueDate: { lte: today },
        },
        include: {
          flashcard: true,
          deck: { select: { title: true } },
        },
        orderBy: { dueDate: "asc" },
        take: 50,
      });

      return NextResponse.json({ cards: reviews });
    }

    // Browse mode - get decks
    const decks = await prisma.flashcardDeck.findMany({
      where: courseId ? { courseId } : {},
      include: {
        creator: { select: { name: true } },
        course: { select: { name: true } },
        _count: { select: { cards: true } },
      },
      orderBy: { downloadCount: "desc" },
    });

    return NextResponse.json({ decks });
  } catch (error) {
    console.error("Flashcards GET Error:", error);
    return NextResponse.json({ error: "Failed to fetch flashcards" }, { status: 500 });
  }
}

// POST /api/flashcards/review - Submit review rating
export async function POST(req: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { flashcardId, rating } = await req.json();
    // rating: "AGAIN" | "HARD" | "GOOD" | "EASY"

    const review = await prisma.flashcardReview.findFirst({
      where: {
        userId: session.user.id,
        flashcardId,
      },
    });

    if (!review) {
      return NextResponse.json({ error: "Review not found" }, { status: 404 });
    }

    // SM-2 Algorithm implementation
    const { newInterval, newEaseFactor, newRepetitions } = calculateSM2(
      review.interval,
      review.easeFactor,
      review.repetitions,
      rating
    );

    const nextReviewDate = new Date();
    nextReviewDate.setDate(nextReviewDate.getDate() + newInterval);

    await prisma.flashcardReview.update({
      where: { id: review.id },
      data: {
        interval: newInterval,
        easeFactor: newEaseFactor,
        repetitions: newRepetitions,
        dueDate: nextReviewDate,
        lastReviewedAt: new Date(),
        nextReviewAt: nextReviewDate,
        status: newRepetitions === 0 ? "RELEARN" : newRepetitions === 1 ? "LEARNING" : "REVIEW",
      },
    });

    return NextResponse.json({
      nextReviewDate,
      interval: newInterval,
      easeFactor: newEaseFactor,
    });
  } catch (error) {
    console.error("Flashcards POST Error:", error);
    return NextResponse.json({ error: "Failed to submit review" }, { status: 500 });
  }
}

function calculateSM2(
  interval: number,
  easeFactor: number,
  repetitions: number,
  rating: string
) {
  const qualityMap: Record<string, number> = {
    AGAIN: 0,
    HARD: 3,
    GOOD: 4,
    EASY: 5,
  };

  const quality = qualityMap[rating] ?? 3;

  let newInterval: number;
  let newRepetitions: number;
  let newEaseFactor: number;

  if (quality < 3) {
    newRepetitions = 0;
    newInterval = 1;
  } else {
    newRepetitions = repetitions + 1;
    if (newRepetitions === 1) {
      newInterval = 1;
    } else if (newRepetitions === 2) {
      newInterval = 6;
    } else {
      newInterval = Math.round(interval * easeFactor);
    }
  }

  newEaseFactor = easeFactor + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02));
  if (newEaseFactor < 1.3) newEaseFactor = 1.3;

  return { newInterval, newEaseFactor, newRepetitions };
}
