import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";

// GET /api/mcq?courseId=X&count=20&difficulty=MEDIUM
export async function GET(req: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const courseId = searchParams.get("courseId");
    const topicId = searchParams.get("topicId");
    const count = Math.min(parseInt(searchParams.get("count") || "20"), 50);
    const difficulty = searchParams.get("difficulty") as any;
    const excludeAttempted = searchParams.get("excludeAttempted") === "true";

    // Check free user limits
    const isPremium = (session.user as any).isPremium ?? false;
    if (!isPremium) {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);

      const attemptsToday = await prisma.mcqAttempt.count({
        where: {
          userId: session.user.id,
          createdAt: { gte: today, lt: tomorrow },
        },
      });

      if (attemptsToday >= 50) {
        return NextResponse.json(
          { error: "Daily MCQ limit reached. Upgrade to Premium for unlimited practice." },
          { status: 429 }
        );
      }
    }

    // Build query
    const where: any = {
      verificationStatus: "VERIFIED",
    };

    if (courseId) where.courseId = courseId;
    if (topicId) where.topicId = topicId;
    if (difficulty) where.difficulty = difficulty;

    if (excludeAttempted) {
      const attemptedIds = await prisma.mcqAttempt.findMany({
        where: { userId: session.user.id },
        select: { questionId: true },
        distinct: ["questionId"],
      });
      where.id = { notIn: attemptedIds.map(a => a.questionId) };
    }

    // Get questions with random ordering
    const questions = await prisma.mcqQuestion.findMany({
      where,
      take: count,
      orderBy: { usageCount: "desc" }, // In production, use proper randomization
      include: {
        course: { select: { name: true } },
        topic: { select: { name: true } },
      },
    });

    // Shuffle options for each question
    const shuffledQuestions = questions.map(q => ({
      ...q,
      options: shuffleArray([...q.options as any[]]),
    }));

    return NextResponse.json({ questions: shuffledQuestions });
  } catch (error) {
    console.error("MCQ GET Error:", error);
    return NextResponse.json({ error: "Failed to fetch questions" }, { status: 500 });
  }
}

// POST /api/mcq/sessions - Create a new session
export async function POST(req: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { courseId, moduleId, topicId, mode, questionCount, questionIds } = body;

    const mcqSession = await prisma.mcqSession.create({
      data: {
        userId: session.user.id,
        courseId,
        moduleId,
        topicId,
        mode: mode || "PRACTICE",
        questionCount,
        questions: questionIds.map((id: string) => ({
          questionId: id,
          userAnswerId: null,
          isCorrect: null,
          timeSpent: 0,
        })),
        score: 0,
        correctCount: 0,
        incorrectCount: 0,
        skippedCount: 0,
        timeSpentMinutes: 0,
        xpEarned: 0,
      },
    });

    // Increment usage count for questions
    await prisma.mcqQuestion.updateMany({
      where: { id: { in: questionIds } },
      data: { usageCount: { increment: 1 } },
    });

    return NextResponse.json({ sessionId: mcqSession.id });
  } catch (error) {
    console.error("MCQ POST Error:", error);
    return NextResponse.json({ error: "Failed to create session" }, { status: 500 });
  }
}

function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}
