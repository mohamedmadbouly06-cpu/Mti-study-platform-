import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";

// PATCH /api/mcq/sessions/[id] - Submit answer
export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { questionId, selectedOptionId, timeSpentSeconds } = await req.json();
    const sessionId = params.id;

    // Get the question to verify correctness
    const question = await prisma.mcqQuestion.findUnique({
      where: { id: questionId },
      select: { correctAnswerId: true, courseId: true, topicId: true },
    });

    if (!question) {
      return NextResponse.json({ error: "Question not found" }, { status: 404 });
    }

    const isCorrect = question.correctAnswerId === selectedOptionId;

    // Record the attempt
    await prisma.mcqAttempt.create({
      data: {
        userId: session.user.id,
        questionId,
        sessionId,
        selectedOptionId,
        isCorrect,
        timeSpentSeconds,
      },
    });

    // Update weak topics
    if (question.topicId) {
      await prisma.weakTopic.upsert({
        where: {
          userId_topicId: {
            userId: session.user.id,
            topicId: question.topicId,
          },
        },
        create: {
          userId: session.user.id,
          topicId: question.topicId,
          wrongCount: isCorrect ? 0 : 1,
          totalAttempts: 1,
          accuracyRate: isCorrect ? 100 : 0,
          lastAttemptAt: new Date(),
        },
        update: {
          wrongCount: { increment: isCorrect ? 0 : 1 },
          totalAttempts: { increment: 1 },
          accuracyRate: {
            set: await calculateAccuracy(session.user.id, question.topicId),
          },
          lastAttemptAt: new Date(),
          isResolved: false,
        },
      });
    }

    return NextResponse.json({ isCorrect, correctAnswerId: question.correctAnswerId });
  } catch (error) {
    console.error("MCQ Session PATCH Error:", error);
    return NextResponse.json({ error: "Failed to submit answer" }, { status: 500 });
  }
}

// POST /api/mcq/sessions/[id]/complete - Complete session
export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const sessionId = params.id;
    const mcqSession = await prisma.mcqSession.findUnique({
      where: { id: sessionId },
      include: { attempts: true },
    });

    if (!mcqSession) {
      return NextResponse.json({ error: "Session not found" }, { status: 404 });
    }

    const correctCount = mcqSession.attempts.filter(a => a.isCorrect).length;
    const total = mcqSession.questionCount;
    const score = (correctCount / total) * 100;
    const xpEarned = correctCount * 30 + (correctCount === total ? 50 : 0);

    // Update session
    await prisma.mcqSession.update({
      where: { id: sessionId },
      data: {
        score,
        correctCount,
        incorrectCount: total - correctCount,
        xpEarned,
        completedAt: new Date(),
      },
    });

    // Update user XP and streak
    await prisma.user.update({
      where: { id: session.user.id },
      data: {
        totalXp: { increment: xpEarned },
      },
    });

    // Update leaderboard
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    await prisma.leaderboardEntry.upsert({
      where: {
        userId_period_periodStart: {
          userId: session.user.id,
          period: "DAILY",
          periodStart: today,
        },
      },
      create: {
        userId: session.user.id,
        period: "DAILY",
        periodStart: today,
        xpEarned,
        mcqsCompleted: total,
      },
      update: {
        xpEarned: { increment: xpEarned },
        mcqsCompleted: { increment: total },
      },
    });

    return NextResponse.json({
      correctCount,
      total,
      score,
      xpEarned,
    });
  } catch (error) {
    console.error("MCQ Session Complete Error:", error);
    return NextResponse.json({ error: "Failed to complete session" }, { status: 500 });
  }
}

async function calculateAccuracy(userId: string, topicId: string): Promise<number> {
  const attempts = await prisma.mcqAttempt.findMany({
    where: {
      userId,
      question: { topicId },
    },
    orderBy: { createdAt: "desc" },
    take: 20,
  });

  if (attempts.length === 0) return 0;
  const correct = attempts.filter(a => a.isCorrect).length;
  return Math.round((correct / attempts.length) * 100);
}
