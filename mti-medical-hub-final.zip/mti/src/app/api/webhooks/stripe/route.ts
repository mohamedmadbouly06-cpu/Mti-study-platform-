import { NextRequest, NextResponse } from "next/server";
import { headers } from "next/headers";
import Stripe from "stripe";
import { prisma } from "@/lib/prisma";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-04-10",
});

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!;

export async function POST(req: NextRequest) {
  try {
    const body = await req.text();
    const signature = headers().get("stripe-signature")!;

    let event: Stripe.Event;

    try {
      event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
    } catch (err: any) {
      console.error(`Webhook signature verification failed: ${err.message}`);
      return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
    }

    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;

        // Update user subscription
        if (session.metadata?.userId) {
          const planId = session.metadata.planId;

          await prisma.userSubscription.create({
            data: {
              userId: session.metadata.userId,
              planId: planId,
              status: "ACTIVE",
              stripeSubscriptionId: session.subscription as string,
              currentPeriodStart: new Date(),
              currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // +30 days
            },
          });

          // Update user to premium
          await prisma.user.update({
            where: { id: session.metadata.userId },
            data: { isPremium: true },
          });
        }
        break;
      }

      case "invoice.payment_succeeded": {
        const invoice = event.data.object as Stripe.Invoice;

        // Update subscription period
        if (invoice.subscription) {
          const subscription = await stripe.subscriptions.retrieve(invoice.subscription as string);

          await prisma.userSubscription.updateMany({
            where: { stripeSubscriptionId: invoice.subscription as string },
            data: {
              currentPeriodStart: new Date(subscription.current_period_start * 1000),
              currentPeriodEnd: new Date(subscription.current_period_end * 1000),
              status: "ACTIVE",
            },
          });
        }
        break;
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription;

        await prisma.userSubscription.updateMany({
          where: { stripeSubscriptionId: subscription.id },
          data: { status: "CANCELLED", cancelledAt: new Date() },
        });

        // Downgrade user
        const userSub = await prisma.userSubscription.findFirst({
          where: { stripeSubscriptionId: subscription.id },
        });

        if (userSub) {
          await prisma.user.update({
            where: { id: userSub.userId },
            data: { isPremium: false },
          });
        }
        break;
      }
    }

    return NextResponse.json({ received: true });
  } catch (error) {
    console.error("Stripe webhook error:", error);
    return NextResponse.json({ error: "Webhook handler failed" }, { status: 500 });
  }
}
