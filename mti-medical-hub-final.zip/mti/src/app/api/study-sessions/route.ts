import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";

// POST /api/study-sessions - Start a study session
export async function POST(req: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { courseId, moduleId, sessionType } = await req.json();

    const studySession = await prisma.studySession.create({
      data: {
        userId: session.user.id,
        courseId,
        moduleId,
        sessionType: sessionType || "LECTURE",
        startTime: new Date(),
      },
    });

    return NextResponse.json({ sessionId: studySession.id });
  } catch (error) {
    console.error("Study session start error:", error);
    return NextResponse.json({ error: "Failed to start session" }, { status: 500 });
  }
}

// PATCH /api/study-sessions/:id - End a study session
export async function PATCH(req: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { sessionId, mcqsAnswered, mcqsCorrect } = await req.json();

    const studySession = await prisma.studySession.findUnique({
      where: { id: sessionId },
    });

    if (!studySession || studySession.userId !== session.user.id) {
      return NextResponse.json({ error: "Session not found" }, { status: 404 });
    }

    const endTime = new Date();
    const durationMinutes = Math.round(
      (endTime.getTime() - studySession.startTime.getTime()) / (1000 * 60)
    );

    const xpEarned = durationMinutes * 2 + (mcqsCorrect || 0) * 10;

    // Update session
    await prisma.studySession.update({
      where: { id: sessionId },
      data: {
        endTime,
        durationMinutes,
        xpEarned,
        mcqsAnswered: mcqsAnswered || 0,
        mcqsCorrect: mcqsCorrect || 0,
      },
    });

    // Update user XP and streak
    await prisma.user.update({
      where: { id: session.user.id },
      data: {
        totalXp: { increment: xpEarned },
      },
    });

    // Update streak
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const userStreak = await prisma.userStreak.findUnique({
      where: { userId: session.user.id },
    });

    if (userStreak) {
      const lastDate = userStreak.lastStudyDate ? new Date(userStreak.lastStudyDate) : null;
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);

      let newStreak = userStreak.currentStreak;

      if (!lastDate || lastDate < yesterday) {
        newStreak = 1; // Reset or start new streak
      } else if (lastDate < today) {
        newStreak += 1; // Continue streak
      }

      const newLongest = Math.max(newStreak, userStreak.longestStreak);

      await prisma.userStreak.update({
        where: { userId: session.user.id },
        data: {
          currentStreak: newStreak,
          longestStreak: newLongest,
          lastStudyDate: today,
        },
      });
    }

    // Update daily goal
    await prisma.dailyGoal.upsert({
      where: {
        userId_date: {
          userId: session.user.id,
          date: today,
        },
      },
      create: {
        userId: session.user.id,
        date: today,
        actualStudyMinutes: durationMinutes,
        actualMcqCount: mcqsAnswered || 0,
      },
      update: {
        actualStudyMinutes: { increment: durationMinutes },
        actualMcqCount: { increment: mcqsAnswered || 0 },
      },
    });

    // Update leaderboard
    await prisma.leaderboardEntry.upsert({
      where: {
        userId_period_periodStart: {
          userId: session.user.id,
          period: "DAILY",
          periodStart: today,
        },
      },
      create: {
        userId: session.user.id,
        period: "DAILY",
        periodStart: today,
        xpEarned,
        studyMinutes: durationMinutes,
      },
      update: {
        xpEarned: { increment: xpEarned },
        studyMinutes: { increment: durationMinutes },
      },
    });

    return NextResponse.json({
      durationMinutes,
      xpEarned,
      newStreak: userStreak?.currentStreak || 1,
    });
  } catch (error) {
    console.error("Study session end error:", error);
    return NextResponse.json({ error: "Failed to end session" }, { status: 500 });
  }
}
