import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const period = searchParams.get("period") || "DAILY";
    const yearId = searchParams.get("yearId");

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    let periodStart: Date;

    switch (period) {
      case "WEEKLY":
        periodStart = new Date(today);
        periodStart.setDate(periodStart.getDate() - periodStart.getDay());
        break;
      case "MONTHLY":
        periodStart = new Date(today.getFullYear(), today.getMonth(), 1);
        break;
      case "ALL_TIME":
        periodStart = new Date(2020, 0, 1);
        break;
      default:
        periodStart = today;
    }

    const entries = await prisma.leaderboardEntry.findMany({
      where: { 
        period: period as any,
        periodStart,
      },
      include: { 
        user: { 
          select: { 
            name: true, 
            image: true,
            yearId: true,
          } 
        } 
      },
      orderBy: { xpEarned: "desc" },
      take: 50,
    });

    // Add rank
    const rankedEntries = entries.map((entry, index) => ({
      ...entry,
      rank: index + 1,
    }));

    return NextResponse.json({ entries: rankedEntries });
  } catch (error) {
    console.error("Leaderboard Error:", error);
    return NextResponse.json({ error: "Failed to fetch leaderboard" }, { status: 500 });
  }
}
