import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Sidebar } from "@/components/layout/Sidebar";
import { MobileHeader } from "@/components/layout/MobileHeader";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });

export const metadata: Metadata = {
  title: "MTI Medical Hub - The Student OS for Medical Students",
  description: "The ultimate platform for medical students. Courses, MCQs, flashcards, AI tutor, and more in one organized platform.",
  keywords: ["medical education", "MTI", "medical students", "MCQ", "flashcards", "AI tutor"],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={inter.variable}>
      <body className="font-sans antialiased bg-slate-50 text-slate-900 min-h-screen">
        <MobileHeader />
        <Sidebar />
        <main className="lg:ml-64 min-h-screen pt-16 lg:pt-0">
          <div className="max-w-6xl mx-auto p-4 lg:p-8">
            {children}
          </div>
        </main>
      </body>
    </html>
  );
}
