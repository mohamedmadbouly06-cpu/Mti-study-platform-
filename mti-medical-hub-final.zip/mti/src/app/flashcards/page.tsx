"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/Button";
import { Plus, RotateCcw } from "lucide-react";

interface Flashcard {
  id: string;
  front: string;
  back: string;
  explanation: string;
}

const SAMPLE_CARDS: Flashcard[] = [
  {
    id: "1",
    front: "What is the mechanism of action of Aspirin?",
    back: "Irreversible inhibition of COX-1 and COX-2 enzymes, reducing prostaglandin synthesis",
    explanation: "This explains both therapeutic effects (analgesic, antipyretic, anti-inflammatory) and adverse effects (GI ulceration, bleeding risk).",
  },
  {
    id: "2",
    front: "What is the therapeutic index (TI) formula?",
    back: "TI = LD50 / ED50",
    explanation: "A higher TI indicates a safer drug. Digoxin has a low TI (2-3), while penicillin has a very high TI.",
  },
  {
    id: "3",
    front: "Which beta-blocker is safest for COPD patients?",
    back: "Bisoprolol",
    explanation: "Highly selective β1-blocker with minimal β2 activity. Non-selective beta-blockers like propranolol can cause bronchospasm.",
  },
  {
    id: "4",
    front: "What is the mechanism of Furosemide?",
    back: "Inhibition of Na+-K+-2Cl- cotransporter (NKCC2) in the thick ascending limb of Loop of Henle",
    explanation: "Loop diuretic. Most potent diuretic class. Causes hypokalemia, hypomagnesemia, and ototoxicity at high doses.",
  },
  {
    id: "5",
    front: "What is the antidote for acetaminophen (paracetamol) overdose?",
    back: "N-acetylcysteine (NAC)",
    explanation: "Replenishes glutathione stores, preventing hepatic necrosis. Most effective within 8 hours of ingestion.",
  },
];

export default function FlashcardsPage() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [showControls, setShowControls] = useState(false);
  const [isStarted, setIsStarted] = useState(false);

  const currentCard = SAMPLE_CARDS[currentIndex];

  const handleFlip = () => {
    if (!isStarted) {
      setIsStarted(true);
      setShowControls(true);
      setIsFlipped(true);
      return;
    }
    setIsFlipped(!isFlipped);
  };

  const handleRate = (rating: "again" | "hard" | "good" | "easy") => {
    console.log("Rated:", rating);
    setIsFlipped(false);
    setTimeout(() => {
      if (currentIndex < SAMPLE_CARDS.length - 1) {
        setCurrentIndex(prev => prev + 1);
      } else {
        // Deck complete
        setCurrentIndex(0);
        setIsStarted(false);
        setShowControls(false);
      }
    }, 200);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Flashcards</h2>
          <p className="text-slate-500 mt-1">Spaced repetition • {SAMPLE_CARDS.length} cards mastered • {SAMPLE_CARDS.length} due today</p>
        </div>
        <Button className="flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Create Deck
        </Button>
      </div>

      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-6">
          <p className="text-sm text-slate-500">
            Card {currentIndex + 1} of {SAMPLE_CARDS.length} • Pharmacology Deck
          </p>
        </div>

        <div 
          className="relative h-80 perspective-1000 cursor-pointer"
          onClick={handleFlip}
        >
          <div 
            className={cn(
              "w-full h-full transition-transform duration-500 transform-style-3d",
              isFlipped && "rotate-y-180"
            )}
          >
            {/* Front */}
            <div className="absolute inset-0 backface-hidden bg-white rounded-2xl border border-slate-200 shadow-xl p-8 flex flex-col items-center justify-center">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Question</span>
              <p className="text-2xl font-bold text-slate-900 text-center leading-relaxed">
                {currentCard.front}
              </p>
              {!isStarted && (
                <p className="text-sm text-slate-400 mt-6">Tap to reveal answer</p>
              )}
            </div>

            {/* Back */}
            <div className="absolute inset-0 backface-hidden rotate-y-180 bg-teal-50 rounded-2xl border border-teal-200 shadow-xl p-8 flex flex-col items-center justify-center">
              <span className="text-xs font-bold text-teal-600 uppercase tracking-wider mb-4">Answer</span>
              <p className="text-xl font-bold text-slate-900 text-center leading-relaxed">
                {currentCard.back}
              </p>
              <div className="mt-6 p-4 bg-white rounded-xl border border-teal-100 w-full">
                <p className="text-sm text-slate-600 leading-relaxed">
                  <span className="font-bold text-teal-700">Why this matters: </span>
                  {currentCard.explanation}
                </p>
              </div>
            </div>
          </div>
        </div>

        {showControls && (
          <div className="mt-6 grid grid-cols-4 gap-3">
            <Button 
              variant="outline" 
              onClick={() => handleRate("again")}
              className="py-3 h-auto border-red-200 text-red-700 hover:bg-red-50"
            >
              <div className="text-center">
                <div className="font-bold">Again</div>
                <div className="text-xs font-normal opacity-70">&lt; 1 min</div>
              </div>
            </Button>
            <Button 
              variant="outline"
              onClick={() => handleRate("hard")}
              className="py-3 h-auto border-amber-200 text-amber-700 hover:bg-amber-50"
            >
              <div className="text-center">
                <div className="font-bold">Hard</div>
                <div className="text-xs font-normal opacity-70">2 days</div>
              </div>
            </Button>
            <Button 
              variant="outline"
              onClick={() => handleRate("good")}
              className="py-3 h-auto border-teal-200 text-teal-700 hover:bg-teal-50"
            >
              <div className="text-center">
                <div className="font-bold">Good</div>
                <div className="text-xs font-normal opacity-70">4 days</div>
              </div>
            </Button>
            <Button 
              variant="outline"
              onClick={() => handleRate("easy")}
              className="py-3 h-auto border-emerald-200 text-emerald-700 hover:bg-emerald-50"
            >
              <div className="text-center">
                <div className="font-bold">Easy</div>
                <div className="text-xs font-normal opacity-70">7 days</div>
              </div>
            </Button>
          </div>
        )}

        {!isStarted && (
          <div className="mt-6 text-center">
            <Button size="lg" onClick={() => setIsStarted(true)}>
              <RotateCcw className="w-4 h-4 mr-2" />
              Start Review Session
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
