"use client";

import { useState } from "react";
import { COURSES } from "@/lib/constants";
import { cn } from "@/lib/utils";
import { BookOpen, FileText, Clock } from "lucide-react";

type FilterType = "all" | "in-progress" | "completed";

export default function CoursesPage() {
  const [filter, setFilter] = useState<FilterType>("all");

  const filteredCourses = COURSES.filter((course) => {
    if (filter === "in-progress") return course.progress > 0 && course.progress < 100;
    if (filter === "completed") return course.progress === 100;
    return true;
  });

  const colorMap: Record<string, { bg: string; text: string; bar: string }> = {
    rose: { bg: "bg-rose-100", text: "text-rose-600", bar: "bg-rose-500" },
    violet: { bg: "bg-violet-100", text: "text-violet-600", bar: "bg-violet-500" },
    emerald: { bg: "bg-emerald-100", text: "text-emerald-600", bar: "bg-emerald-500" },
    amber: { bg: "bg-amber-100", text: "text-amber-600", bar: "bg-amber-500" },
    orange: { bg: "bg-orange-100", text: "text-orange-600", bar: "bg-orange-500" },
    cyan: { bg: "bg-cyan-100", text: "text-cyan-600", bar: "bg-cyan-500" },
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Courses</h2>
          <p className="text-slate-500 mt-1">Year 2 • Semester 1 • {COURSES.length} courses</p>
        </div>
        <div className="flex gap-2">
          {(["all", "in-progress", "completed"] as FilterType[]).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "px-4 py-2 rounded-xl text-sm font-bold transition-all",
                filter === f 
                  ? "bg-teal-50 text-teal-700 border border-teal-200" 
                  : "bg-white text-slate-600 border border-slate-200 hover:bg-slate-50"
              )}
            >
              {f === "in-progress" ? "In Progress" : f === "completed" ? "Completed" : "All"}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredCourses.map((course) => {
          const colors = colorMap[course.color] || colorMap.rose;
          const isNotStarted = course.progress === 0;

          return (
            <div 
              key={course.id}
              className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 hover:shadow-md transition-all cursor-pointer group"
            >
              <div className="flex items-start justify-between mb-4">
                <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center text-2xl", colors.bg)}>
                  {course.icon}
                </div>
                <span className={cn(
                  "text-xs font-bold px-3 py-1 rounded-full",
                  isNotStarted ? "bg-slate-50 text-slate-400" : `${colors.bg} ${colors.text}`
                )}>
                  {isNotStarted ? "Not Started" : `${course.progress}% Complete`}
                </span>
              </div>
              <h3 className="text-lg font-bold text-slate-900 group-hover:text-teal-600 transition-colors">
                {course.name}
              </h3>
              <p className="text-sm text-slate-500 mt-1 flex items-center gap-3">
                <span className="flex items-center gap-1">
                  <BookOpen className="w-3 h-3" />
                  {course.professor}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {course.totalLectures} lectures
                </span>
                <span className="flex items-center gap-1">
                  <FileText className="w-3 h-3" />
                  {course.totalPdfs} PDFs
                </span>
              </p>
              <div className="mt-4 w-full bg-slate-100 rounded-full h-2">
                <div 
                  className={cn("h-2 rounded-full transition-all duration-500", colors.bar)} 
                  style={{ width: `${course.progress}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
