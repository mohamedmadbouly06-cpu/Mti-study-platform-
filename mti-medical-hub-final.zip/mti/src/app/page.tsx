import { StreakCard } from "@/components/dashboard/StreakCard";
import { DailyGoals } from "@/components/dashboard/DailyGoals";
import { DailyRoadmap } from "@/components/dashboard/DailyRoadmap";
import { WeeklyActivity } from "@/components/dashboard/WeeklyActivity";
import { UpcomingExams } from "@/components/dashboard/UpcomingExams";
import { DAILY_ROADMAP, UPCOMING_EXAMS } from "@/lib/constants";

const dailyGoals = [
  { label: "Study Time", current: 45, target: 60, unit: "min", color: "#0d9488" },
  { label: "MCQs", current: 18, target: 20, unit: "qs", color: "#0d9488" },
  { label: "Flashcards", current: 0, target: 30, unit: "cards", color: "#cbd5e1" },
];

const rawWeeklyData = [
  { day: "Mon", minutes: 45 },
  { day: "Tue", minutes: 75 },
  { day: "Wed", minutes: 60 },
  { day: "Thu", minutes: 30 },
  { day: "Fri", minutes: 90 },
  { day: "Sat", minutes: 55 },
  { day: "Sun", minutes: 15 },
];
const maxMinutes = Math.max(...rawWeeklyData.map((d) => d.minutes));
const weeklyData = rawWeeklyData.map((d) => ({ ...d, maxMinutes }));

export default function DashboardPage() {
  return (
    <div className="space-y-6 animate-fade-in">
      {/* Welcome Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Good morning, Omar 👋</h2>
          <p className="text-slate-500 mt-1">Year 2 • Faculty of Medicine</p>
        </div>
        <StreakCard streak={12} xp={2450} />
      </div>

      {/* Daily Goals */}
      <DailyGoals goals={dailyGoals} />

      {/* Today's Roadmap */}
      <DailyRoadmap items={DAILY_ROADMAP} />

      {/* Weekly Progress + Upcoming */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <WeeklyActivity data={weeklyData} />
        <UpcomingExams exams={[...UPCOMING_EXAMS]} />
      </div>
    </div>
  );
}
