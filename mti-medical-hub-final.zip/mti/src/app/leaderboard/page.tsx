"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";
import { LEADERBOARD_DATA } from "@/lib/constants";
import { Trophy, Crown } from "lucide-react";

type Period = "daily" | "weekly" | "monthly";

export default function LeaderboardPage() {
  const [period, setPeriod] = useState<Period>("daily");

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-slate-900">Leaderboard</h2>
        <p className="text-slate-500 mt-1">Compete with your classmates • Resets every Sunday</p>
      </div>

      <div className="flex justify-center gap-2">
        {(["daily", "weekly", "monthly"] as Period[]).map((p) => (
          <button
            key={p}
            onClick={() => setPeriod(p)}
            className={cn(
              "px-4 py-2 rounded-xl text-sm font-bold transition-all",
              period === p 
                ? "bg-teal-600 text-white shadow-lg shadow-teal-600/20" 
                : "bg-white text-slate-600 border border-slate-200 hover:bg-slate-50"
            )}
          >
            {p.charAt(0).toUpperCase() + p.slice(1)}
          </button>
        ))}
      </div>

      {/* Top 3 Podium */}
      <div className="flex items-end justify-center gap-4 mb-8">
        {[
          { rank: 2, data: LEADERBOARD_DATA[1], height: "h-24", bg: "bg-slate-200", border: "border-slate-300" },
          { rank: 1, data: LEADERBOARD_DATA[0], height: "h-32", bg: "bg-amber-100", border: "border-amber-400", isFirst: true },
          { rank: 3, data: LEADERBOARD_DATA[2], height: "h-20", bg: "bg-orange-100", border: "border-orange-400" },
        ].map((item) => (
          <div key={item.rank} className="flex flex-col items-center">
            <div className={cn(
              "w-16 h-16 rounded-full flex items-center justify-center text-2xl mb-2 border-4",
              item.isFirst ? "bg-amber-100 border-amber-400 shadow-lg shadow-amber-400/30" : `${item.bg} ${item.border}`
            )}>
              {item.isFirst ? <Crown className="w-8 h-8 text-amber-600" /> : <span className="text-2xl">{item.rank === 2 ? "🥈" : "🥉"}</span>}
            </div>
            <p className={cn("font-bold text-slate-900", item.isFirst && "text-lg")}>{item.data.name}</p>
            <p className={cn("text-sm font-bold", item.isFirst ? "text-amber-600" : "text-slate-500")}>
              {item.data.xp.toLocaleString()} XP
            </p>
            <div className={cn("w-24 rounded-t-xl mt-2", item.height, item.bg, item.border.replace("border", "border-t-4"))} />
          </div>
        ))}
      </div>

      {/* List */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden max-w-2xl mx-auto">
        <div className="divide-y divide-slate-100">
          {LEADERBOARD_DATA.slice(3).map((entry) => (
            <div 
              key={entry.rank} 
              className="p-4 flex items-center gap-4 hover:bg-slate-50 transition-colors"
            >
              <span className="w-8 text-center font-bold text-slate-400">{entry.rank}</span>
              <div className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold",
                entry.isCurrentUser ? "bg-teal-100 text-teal-700" : "bg-slate-100 text-slate-600"
              )}>
                {entry.initials}
              </div>
              <div className="flex-1">
                <p className={cn("font-bold", entry.isCurrentUser ? "text-teal-700" : "text-slate-900")}>
                  {entry.name} {entry.isCurrentUser && "(You)"}
                </p>
                <p className="text-xs text-slate-500">Year 2 • {entry.xp.toLocaleString()} XP today</p>
              </div>
              <span className="text-sm font-bold text-slate-900">{entry.xp.toLocaleString()}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
