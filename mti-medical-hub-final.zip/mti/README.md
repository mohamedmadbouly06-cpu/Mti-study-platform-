# MTI Medical Hub

> **The Student Operating System for Medical Students**

[![Next.js](https://img.shields.io/badge/Next.js-14-black)](https://nextjs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.4-blue)](https://www.typescriptlang.org/)
[![Prisma](https://img.shields.io/badge/Prisma-5.14-2D3748)](https://prisma.io/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind-3.4-38B2AC)](https://tailwindcss.com/)
[![Supabase](https://img.shields.io/badge/Supabase-PostgreSQL-3ECF8E)](https://supabase.com/)

## 🚀 What is MTI Medical Hub?

The ultimate platform that every medical student opens every single day. Not just another course website — a complete academic ecosystem.

**Built for:** MTI University Faculty of Medicine (Phase 1: Years 1-3)

**Core Philosophy:** Own the daily habit. If students don't open it every morning, we failed.

## ✨ Features

| Feature | Status | Description |
|---------|--------|-------------|
| 📊 **Dashboard** | ✅ Live | Daily roadmap, streaks, XP, progress rings, weekly activity |
| 📚 **Courses** | ✅ Live | Organized course library with progress tracking |
| ❓ **MCQ Engine** | ✅ Live | Interactive quiz sessions with immediate feedback & explanations |
| 🗂️ **Flashcards** | ✅ Live | 3D flip cards with SM-2 spaced repetition algorithm |
| 🤖 **AI Tutor** | ✅ Live | GPT-4o powered tutor with MTI-specific knowledge |
| 🏆 **Leaderboard** | ✅ Live | Daily/weekly/monthly rankings with podium view |
| 💳 **Pricing** | ✅ Live | 3-tier subscriptions (Free, Monthly, Semester) |
| 🔐 **Auth** | ✅ Ready | Google OAuth + university email verification |
| 📱 **Mobile** | 🔄 PWA | Responsive design, native app coming soon |

## 🏗️ Architecture

```
mti-medical-hub/
├── src/
│   ├── app/                    # Next.js 14 App Router
│   │   ├── api/               # API Routes (REST + Edge)
│   │   │   ├── ai/chat/      # OpenAI GPT-4o integration
│   │   │   ├── mcq/          # MCQ session management
│   │   │   ├── flashcards/   # Spaced repetition engine
│   │   │   └── leaderboard/  # Rankings & stats
│   │   ├── (pages)/          # Route groups
│   │   │   ├── page.tsx      # Dashboard
│   │   │   ├── courses/      # Course catalog
│   │   │   ├── mcq/          # MCQ bank & sessions
│   │   │   ├── flashcards/   # Flashcard review
│   │   │   ├── ai/           # AI Tutor chat
│   │   │   ├── leaderboard/  # Rankings
│   │   │   └── pricing/      # Subscription plans
│   │   ├── layout.tsx        # Root layout with sidebar
│   │   └── globals.css       # Tailwind + custom styles
│   ├── components/
│   │   ├── layout/           # Sidebar, MobileHeader
│   │   ├── dashboard/        # StreakCard, DailyGoals, Roadmap
│   │   ├── mcq/              # Lobby, Session, Summary
│   │   └── ui/               # ProgressRing, Button (reusable)
│   ├── lib/
│   │   ├── prisma.ts         # Database client (singleton)
│   │   ├── auth.ts           # NextAuth v5 configuration
│   │   ├── utils.ts          # cn(), formatters, streak calc
│   │   └── constants.ts      # App config, demo data
│   └── types/                # TypeScript definitions
├── prisma/
│   ├── schema.prisma         # 30+ tables, full relations
│   └── seed.ts               # Initial data (courses, MCQs, etc.)
├── public/                   # Static assets
└── package.json
```

## 🛠️ Tech Stack

| Layer | Technology | Why |
|-------|-----------|-----|
| **Framework** | Next.js 14 (App Router) | RSC, streaming, API routes in one |
| **Language** | TypeScript 5.4 | Type safety across full stack |
| **Styling** | Tailwind CSS 3.4 | Utility-first, rapid UI development |
| **Database** | PostgreSQL (Supabase) | Managed, scalable, real-time |
| **ORM** | Prisma 5.14 | Type-safe queries, migrations |
| **Auth** | Auth.js v5 (NextAuth) | OAuth, JWT, session management |
| **AI** | OpenAI GPT-4o | Best reasoning for medical content |
| **Payments** | Stripe + Fawry | Cards + Egyptian cash payments |
| **Hosting** | Vercel | Edge network, zero-config deploy |

## 🚀 Deployment Guide

### Prerequisites

- Node.js 18+ and npm
- A Supabase account (free tier works)
- A Google Cloud project (for OAuth)
- An OpenAI API key
- A Stripe account (for payments)

### Step 1: Clone & Install

```bash
git clone https://github.com/yourusername/mti-medical-hub.git
cd mti-medical-hub
npm install
```

### Step 2: Set up Supabase

1. Go to [supabase.com](https://supabase.com) and create a new project
2. Name it `mti-medical-hub`
3. Choose the **US East** region (closest to Egypt for latency)
4. Copy the connection details:
   - Go to Project Settings → Database
   - Copy the **Connection string** (URI tab)
   - Copy the **Direct connection string** (for migrations)

### Step 3: Configure Environment Variables

```bash
cp .env.example .env.local
```

Fill in these values:

```env
# Database (from Supabase Dashboard)
DATABASE_URL="postgresql://postgres:[password]@db.[project-ref].supabase.co:5432/postgres"
DIRECT_URL="postgresql://postgres:[password]@db.[project-ref].supabase.co:5432/postgres"

# Supabase (from Project Settings → API)
NEXT_PUBLIC_SUPABASE_URL="https://[project-ref].supabase.co"
NEXT_PUBLIC_SUPABASE_ANON_KEY="[anon-key]"
SUPABASE_SERVICE_ROLE_KEY="[service-role-key]"

# Auth (generate with: openssl rand -base64 32)
AUTH_SECRET="your-generated-secret"

# Google OAuth (from Google Cloud Console)
AUTH_GOOGLE_ID="[google-client-id].apps.googleusercontent.com"
AUTH_GOOGLE_SECRET="[google-client-secret]"

# OpenAI (from platform.openai.com)
OPENAI_API_KEY="sk-[your-key]"

# Stripe (from dashboard.stripe.com)
STRIPE_SECRET_KEY="sk_test_[your-key]"
STRIPE_WEBHOOK_SECRET="whsec_[your-webhook-secret]"
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY="pk_test_[your-key]"

# App
NEXT_PUBLIC_APP_URL="http://localhost:3000"
```

### Step 4: Initialize Database

```bash
# Generate Prisma client
npx prisma generate

# Push schema to Supabase
npx prisma db push

# Seed with initial data (courses, MCQs, flashcards, plans)
npx prisma db seed
```

### Step 5: Run Locally

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

### Step 6: Deploy to Vercel

```bash
# Install Vercel CLI
npm i -g vercel

# Login
vercel login

# Deploy
vercel --prod
```

**Required Vercel Environment Variables:**
Copy all variables from `.env.local` into Vercel Project Settings → Environment Variables.

**After first deploy:**
1. Go to Vercel Dashboard → Your Project → Settings → Domains
2. Add your custom domain (e.g., `mti-hub.vercel.app`)
3. Update `NEXT_PUBLIC_APP_URL` to match

### Step 7: Configure Google OAuth

1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. APIs & Services → Credentials → Create OAuth 2.0 Client ID
3. Application type: Web application
4. Authorized redirect URIs:
   - `http://localhost:3000/api/auth/callback/google` (dev)
   - `https://your-domain.vercel.app/api/auth/callback/google` (prod)
5. Copy Client ID and Secret to your `.env.local`

### Step 8: Configure Stripe Webhooks

1. Go to Stripe Dashboard → Developers → Webhooks
2. Add endpoint: `https://your-domain.vercel.app/api/webhooks/stripe`
3. Select events:
   - `checkout.session.completed`
   - `invoice.payment_succeeded`
   - `customer.subscription.deleted`
4. Copy the webhook signing secret to `STRIPE_WEBHOOK_SECRET`

### Step 9: Configure Fawry (Egyptian Payments)

1. Sign up at [fawry.com](https://fawry.com) for merchant account
2. Get your Merchant Code and Security Key
3. Add to environment variables:
   ```env
   FAWRY_MERCHANT_CODE="your-merchant-code"
   FAWRY_SECURITY_KEY="your-security-key"
   ```
4. Implement Fawry API calls in `src/app/api/payments/fawry/route.ts`

## 📊 Database Schema

The schema includes 30+ tables covering:

- **Users & Auth**: Users, Accounts, Sessions, VerificationTokens
- **Academic Structure**: Years, Courses, Modules, Topics
- **Content Library**: ContentItems, ContentVersions, Professors, Announcements
- **Gamification**: UserStreaks, DailyGoals, StudySessions, UserProgress, LeaderboardEntries
- **MCQ Engine**: McqQuestions, McqSessions, McqAttempts, WeakTopics
- **Flashcards**: FlashcardDecks, Flashcards, FlashcardReviews (SM-2 algorithm)
- **AI System**: AiConversations, AiMessages, AiStudyPlans, AiExamPredictions, AiUsage
- **Payments**: SubscriptionPlans, UserSubscriptions, Payments
- **Exams**: Exams, Exam calendar integration

## 🎯 Business Model

| Plan | Price | Target |
|------|-------|--------|
| **Free** | 0 EGP | Acquisition — content library + limited MCQs/AI |
| **Premium Monthly** | 149 EGP | Core revenue — unlimited everything |
| **Premium Semester** | 399 EGP | Retention — 33% discount, locks in users |

**Payment Methods:**
- 💳 Credit/Debit cards (Stripe)
- 🏪 Fawry cash payments (100,000+ locations across Egypt)
- 📱 Vodafone Cash / Etisalat Cash

## 📈 Metrics to Track

| Metric | Target | Tool |
|--------|--------|------|
| DAU/MAU | >40% | Vercel Analytics + custom events |
| Dashboard-to-Session | >30% | Custom tracking |
| Free-to-Premium | >10% | Stripe dashboard |
| Day 7 Retention | >50% | Mixpanel/Amplitude |
| NPS | >50 | In-app survey |

## 🧪 Testing

```bash
# Run linting
npm run lint

# Type check
npx tsc --noEmit

# Database integrity check
npx prisma validate
```

## 📝 Content Strategy (Critical!)

**Before launch, you MUST:**

1. **Seed 500+ verified MCQs** per course (use the seed script as template)
2. **Upload all lecture PDFs** via the content upload system
3. **Recruit 10 Campus Ambassadors** to bulk-upload their organized notes
4. **Get 2-3 professors** to post announcements and upload slides
5. **Create study roadmaps** for each year/semester

**Without content, no students will stay. With content, they can't leave.**

## 🗺️ Roadmap

### Phase 1: MVP (Weeks 1-4)
- [x] Dashboard with daily roadmap
- [x] MCQ engine with sessions
- [x] Basic flashcards
- [x] AI Tutor (chat mode)
- [x] Leaderboard
- [x] Pricing page
- [ ] Professor portal
- [ ] Content upload system
- [ ] Mobile PWA

### Phase 2: Growth (Months 2-3)
- [ ] AI Exam Predictor
- [ ] Smart Study Plans
- [ ] Campus Ambassador system
- [ ] Push notifications
- [ ] Social features (study groups)
- [ ] B2B university licensing

### Phase 3: Scale (Months 4-6)
- [ ] Other Egyptian universities
- [ ] Marketplace (student notes)
- [ ] Instructor revenue sharing
- [ ] Advanced analytics dashboard
- [ ] Native mobile apps (iOS/Android)

## 🤝 Contributing

This is a startup project. We move fast and break things (then fix them).

**How to contribute:**
1. Fork the repo
2. Create a feature branch: `git checkout -b feature/amazing-thing`
3. Commit: `git commit -m "Add amazing thing"`
4. Push: `git push origin feature/amazing-thing`
5. Open a PR

## 📄 License

MIT License — build something great.

## 🙏 Acknowledgments

- Design inspired by Duolingo, Notion, Linear, and Apple
- Built for MTI University medical students
- Powered by open-source: Next.js, Prisma, Tailwind, Supabase

---

**Built with ❤️ for medical students who deserve better than scattered PDFs and WhatsApp chaos.**
