# 🚀 MTI Medical Hub — Deployment Checklist

## ✅ What You Have
- [x] Complete Next.js 14 project with TypeScript
- [x] 30+ table Prisma schema (PostgreSQL)
- [x] 6 main pages (Dashboard, Courses, MCQ, Flashcards, AI, Leaderboard, Pricing)
- [x] Full API routes (AI Chat, MCQ Engine, Flashcards, Leaderboard, Payments)
- [x] Auth.js v5 with Google OAuth
- [x] Stripe webhook + checkout integration
- [x] Seed script with sample data
- [x] Docker + Docker Compose setup
- [x] GitHub Actions CI/CD workflow
- [x] Comprehensive README

## 🎯 Your 30-Minute Deployment Plan

### Step 1: Get Accounts (5 min)
- [ ] Supabase: supabase.com → New Project → Copy connection strings
- [ ] OpenAI: platform.openai.com → Create API key
- [ ] Google Cloud: console.cloud.google.com → Create OAuth credentials
- [ ] Stripe: dashboard.stripe.com → Get test keys
- [ ] Vercel: vercel.com → Sign up with GitHub

### Step 2: Configure (10 min)
- [ ] `cp .env.example .env.local`
- [ ] Fill in all API keys from Step 1
- [ ] `npm install`
- [ ] `npx prisma generate`
- [ ] `npx prisma db push`
- [ ] `npx prisma db seed`

### Step 3: Test Locally (5 min)
- [ ] `npm run dev`
- [ ] Open http://localhost:3000
- [ ] Test: Dashboard → MCQ Session → AI Chat → Pricing
- [ ] Verify database: `npx prisma studio`

### Step 4: Deploy (10 min)
- [ ] Push to GitHub
- [ ] Import repo to Vercel
- [ ] Add all env vars to Vercel dashboard
- [ ] Deploy!
- [ ] Configure Stripe webhooks with production URL
- [ ] Configure Google OAuth redirect URIs

## 🚨 Critical Before Launch

### Content (Week 1 Priority)
- [ ] Upload 500+ verified MCQs (use seed script as template)
- [ ] Upload all lecture PDFs for Year 2
- [ ] Create study roadmaps for each semester
- [ ] Recruit 10 Campus Ambassadors
- [ ] Get 2-3 professors to use the platform

### Payments (Before First User)
- [ ] Set up Stripe live mode
- [ ] Apply for Fawry merchant account
- [ ] Test payment flow end-to-end
- [ ] Configure subscription webhooks

### Monitoring (Day 1)
- [ ] Set up Vercel Analytics
- [ ] Configure error tracking (Sentry)
- [ ] Set up uptime monitoring
- [ ] Create support email/Discord

## 📞 Need Help?

**Common Issues:**
1. **Prisma generate fails** → Run `npm install` first, then `npx prisma generate`
2. **Database connection error** → Check DATABASE_URL format in .env.local
3. **Auth not working** → Verify AUTH_SECRET and Google OAuth redirect URIs
4. **AI not responding** → Check OPENAI_API_KEY and usage limits
5. **Build fails on Vercel** → Ensure all env vars are set in Vercel dashboard

**Next Steps After Deploy:**
1. Invite 50 beta users (fellow MTI students)
2. Collect feedback for 1 week
3. Fix critical bugs
4. Launch to full Year 2
5. Measure DAU/MAU and conversion rates

---

**You now have everything needed to deploy.** 
The only thing between you and a live product is running these commands.
